import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/generate-image-CYKbKZiO.js
var STYLE = "Photorealistic original Christian fine-art background for a premium wall canvas. Cinematic natural lighting, realistic color, respectful sacred atmosphere, no people crowded in the foreground unless asked, no text, no watermark, no logos, no brand marks. Do not copy or imitate a famous painting, photographer, church, or commercial canvas design. Original composition only.";
var generateOriginalImage_createServerFn_handler = createServerRpc({
	id: "ce0622dc9c7af0d1fd9c989df4013448ca588fdd7fa263f8f3daeca30b56c2a2",
	name: "generateOriginalImage",
	filename: "src/lib/ai/generate-image.ts"
}, (opts) => generateOriginalImage.__executeServer(opts));
var generateOriginalImage = createServerFn({ method: "POST" }).validator((input) => input).handler(generateOriginalImage_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Original image generation is not available right now."
	};
	const userPrompt = data.prompt.trim().slice(0, 400);
	if (userPrompt.length < 8) return {
		ok: false,
		error: "Please describe the scene in a little more detail."
	};
	try {
		const res = await fetch("https://api.x.ai/v1/images/generations", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-imagine-image",
				prompt: `${userPrompt}. ${STYLE}`,
				n: 1,
				resolution: "1k",
				aspect_ratio: "3:4",
				response_format: "b64_json"
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `Could not generate an image (${res.status}).`
		};
		const first = (await res.json()).data?.[0];
		if (first?.b64_json) return {
			ok: true,
			dataUrl: `data:image/png;base64,${first.b64_json}`
		};
		if (first?.url) {
			const imgRes = await fetch(first.url);
			if (!imgRes.ok) return {
				ok: false,
				error: "Could not download the generated image."
			};
			const buf = Buffer.from(await imgRes.arrayBuffer());
			return {
				ok: true,
				dataUrl: `data:${imgRes.headers.get("content-type") || "image/png"};base64,${buf.toString("base64")}`
			};
		}
		return {
			ok: false,
			error: "The generator returned an empty image."
		};
	} catch {
		return {
			ok: false,
			error: "Image generation failed. Please try again."
		};
	}
});
//#endregion
export { generateOriginalImage_createServerFn_handler };
