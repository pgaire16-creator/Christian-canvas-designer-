import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analyze-cDotTfdI.js
var analyzeLayout_createServerFn_handler = createServerRpc({
	id: "9a42130912e01ee513b6f5f429c9bc16226359f5efb8a278d7438df7ac9c9762",
	name: "analyzeLayout",
	filename: "src/lib/ai/analyze.ts"
}, (opts) => analyzeLayout.__executeServer(opts));
var analyzeLayout = createServerFn({ method: "POST" }).validator((input) => input).handler(analyzeLayout_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available"
	};
	const prompt = `You are an art director for premium Christian wall canvases sold as home decor.
Analyze the uploaded image and the Bible verse. Return ONLY JSON with this shape:
{
  "subjectX": number 0-1,
  "subjectY": number 0-1,
  "textAnchor": "top" | "bottom" | "left" | "right",
  "textColor": "#f4efe6" or "#1c1812",
  "overlayColor": "#120e0a" or "#f4efe6",
  "needsOverlay": boolean,
  "overlayOpacity": number 0-1,
  "faceRegion": { "x": 0-1, "y": 0-1, "w": 0-1, "h": 0-1 } or null,
  "enhancement": {
    "brightness": number -0.18 to 0.18,
    "contrast": number -0.08 to 0.28,
    "saturation": number -0.12 to 0.16,
    "temperature": number -0.2 to 0.22,
    "vignette": number 0 to 0.42
  }
}
Rules:
- Keep faces, figures of Jesus, and important bodies fully inside the inner 84% safe print area.
- Place the verse in calm negative space. Never cover a face unless there is no other option.
- If the text region is busy or high-contrast, needsOverlay must be true.
- If the region behind text is bright, use dark text (#1c1812). If dark, use cream text (#f4efe6).
- Keep the photo realistic and respectful. Do not suggest extreme color grading.
- Canvas size: ${data.canvasLabel}
- Verse: ${data.verse.slice(0, 500)}`;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .2,
				max_tokens: 700,
				response_format: { type: "json_object" },
				messages: [{
					role: "user",
					content: [{
						type: "text",
						text: prompt
					}, {
						type: "image_url",
						image_url: {
							url: data.imageDataUrl,
							detail: "low"
						}
					}]
				}]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `xAI API error ${res.status}`
		};
		const layout = parseLayout((await res.json()).choices?.[0]?.message?.content ?? "");
		if (!layout) return {
			ok: false,
			error: "Could not parse layout"
		};
		return {
			ok: true,
			layout
		};
	} catch {
		return {
			ok: false,
			error: "Layout analysis failed"
		};
	}
});
function parseLayout(content) {
	const trimmed = content.trim();
	const block = trimmed.startsWith("{") ? trimmed : trimmed.match(/\{[\s\S]*\}/)?.[0] ?? "";
	if (!block) return null;
	try {
		return JSON.parse(block);
	} catch {
		return null;
	}
}
//#endregion
export { analyzeLayout_createServerFn_handler };
