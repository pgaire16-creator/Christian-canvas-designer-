import { o as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Sparkles, c as Download, l as ArrowLeft, n as Upload, o as Redo2, r as Undo2, s as ImagePlus, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as require_jspdf_node_min } from "../_libs/jspdf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C5YKOnm-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_jspdf_node_min = require_jspdf_node_min();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function sleep(ms) {
	return new Promise((resolve) => {
		setTimeout(resolve, ms);
	});
}
function uid() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.rel = "noopener";
	document.body.appendChild(a);
	a.click();
	a.remove();
	window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60 disabled:pointer-events-none disabled:opacity-40 [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-cream text-ink shadow-[0_0_0_1px_rgba(244,239,230,0.12)] hover:bg-parchment",
			gold: "bg-transparent text-gold shadow-[0_0_0_1px_rgba(176,141,87,0.45)] hover:bg-gold/10",
			ghost: "bg-transparent text-muted hover:text-cream hover:bg-bg-subtle",
			ink: "bg-ink text-cream hover:bg-bg-elevated"
		},
		size: {
			md: "h-11 px-4 text-sm",
			lg: "h-12 px-5 text-sm tracking-[0.08em]",
			sm: "h-9 px-3 text-xs",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function CrossMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 32",
		className,
		"aria-hidden": "true",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.25",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 2v28M5 11h14",
			strokeLinecap: "round"
		})
	});
}
var CANVAS_SIZES = [
	{
		id: "auto",
		label: "Auto",
		widthIn: 16,
		heightIn: 20,
		auto: true
	},
	{
		id: "12x16",
		label: "12 × 16 in",
		widthIn: 12,
		heightIn: 16
	},
	{
		id: "16x20",
		label: "16 × 20 in",
		widthIn: 16,
		heightIn: 20
	},
	{
		id: "18x24",
		label: "18 × 24 in",
		widthIn: 18,
		heightIn: 24
	},
	{
		id: "a4",
		label: "A4",
		widthIn: 8.27,
		heightIn: 11.69
	},
	{
		id: "a3",
		label: "A3",
		widthIn: 11.69,
		heightIn: 16.54
	},
	{
		id: "18x25",
		label: "18 × 25 in",
		widthIn: 18,
		heightIn: 25
	},
	{
		id: "custom",
		label: "Custom",
		widthIn: 16,
		heightIn: 20,
		custom: true
	}
];
function getCanvasSize(id, customWidth = 16, customHeight = 20) {
	const found = CANVAS_SIZES.find((s) => s.id === id) ?? CANVAS_SIZES[1];
	if (found.custom) return {
		...found,
		widthIn: clampSize(customWidth),
		heightIn: clampSize(customHeight),
		label: `${formatIn(customWidth)} × ${formatIn(customHeight)} in`
	};
	return found;
}
function clampSize(n) {
	if (!Number.isFinite(n)) return 16;
	return Math.min(40, Math.max(6, n));
}
function formatIn(n) {
	const rounded = Math.round(n * 100) / 100;
	return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2);
}
function pickAutoSize(imageAspect) {
	const presets = CANVAS_SIZES.filter((s) => !s.auto && !s.custom);
	let best = presets[1] ?? presets[0];
	let bestDelta = Infinity;
	for (const size of presets) {
		const delta = Math.abs(size.widthIn / size.heightIn - imageAspect);
		if (delta < bestDelta) {
			best = size;
			bestDelta = delta;
		}
	}
	return best;
}
function exportDpi(widthIn, heightIn) {
	const area = widthIn * heightIn;
	if (area >= 420) return 140;
	if (area >= 300) return 160;
	return 180;
}
function formatFileSizeLabel(size) {
	return size.id === "custom" ? size.label.replace(/\s/g, "") : size.id;
}
function exportBasename(size) {
	return `christian-canvas-${formatFileSizeLabel(size)}`;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var analyzeLayout = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("9a42130912e01ee513b6f5f429c9bc16226359f5efb8a278d7438df7ac9c9762"));
var SAMPLE_VERSES = [
	{
		id: "john-3-16",
		reference: "John 3:16",
		text: "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life."
	},
	{
		id: "psalm-23",
		reference: "Psalm 23:1",
		text: "The Lord is my shepherd; I shall not want."
	},
	{
		id: "phil-4-13",
		reference: "Philippians 4:13",
		text: "I can do all things through Christ who strengthens me."
	},
	{
		id: "isaiah-41-10",
		reference: "Isaiah 41:10",
		text: "Fear not, for I am with you; be not dismayed, for I am your God. I will strengthen you, I will help you, I will uphold you with my righteous right hand."
	},
	{
		id: "jer-29-11",
		reference: "Jeremiah 29:11",
		text: "For I know the plans I have for you, declares the Lord, plans for welfare and not for evil, to give you a future and a hope."
	},
	{
		id: "prov-3-5",
		reference: "Proverbs 3:5-6",
		text: "Trust in the Lord with all your heart, and do not lean on your own understanding. In all your ways acknowledge him, and he will make straight your paths."
	},
	{
		id: "rom-8-28",
		reference: "Romans 8:28",
		text: "And we know that for those who love God all things work together for good, for those who are called according to his purpose."
	},
	{
		id: "john-14-6",
		reference: "John 14:6",
		text: "Jesus said to him, “I am the way, and the truth, and the life. No one comes to the Father except through me.”"
	}
];
var REF_LINE = /^(?:[-–—]\s*)?((?:(?:[1-3]|I{1,3})\s*)?[A-Za-z][A-Za-z.'’]+(?:\s+[A-Za-z][A-Za-z.'’]+){0,3})\s+(\d{1,3}\s*:\s*\d{1,3}(?:\s*[-–—]\s*\d{1,3})?)\s*$/;
var REF_TAIL = /(?:[-–—]\s*)?((?:(?:[1-3]|I{1,3})\s*)?[A-Za-z][A-Za-z.'’]+(?:\s+[A-Za-z][A-Za-z.'’]+){0,3})\s+(\d{1,3}\s*:\s*\d{1,3}(?:\s*[-–—]\s*\d{1,3})?)\s*$/;
function parseVerse(raw) {
	const trimmed = raw.trim();
	if (!trimmed) return {
		text: "",
		reference: ""
	};
	const lines = trimmed.split(/\n+/);
	const last = (lines[lines.length - 1] ?? "").trim();
	if (lines.length > 1 && last.length < 48) {
		const lineMatch = last.match(REF_LINE);
		if (lineMatch) return {
			text: lines.slice(0, -1).join("\n").trim(),
			reference: normalizeRef(lineMatch[1], lineMatch[2])
		};
	}
	const tail = trimmed.match(REF_TAIL);
	if (tail && tail.index !== void 0 && tail.index > 12) return {
		text: trimmed.slice(0, tail.index).replace(/[-–—\s]+$/, "").trim(),
		reference: normalizeRef(tail[1], tail[2])
	};
	return {
		text: trimmed,
		reference: ""
	};
}
function formatVerseInput(text, reference) {
	const body = text.trim();
	const ref = reference.trim();
	if (!ref) return body;
	if (!body) return ref;
	return `${body}\n${ref}`;
}
function normalizeRef(book, verse) {
	return `${book.replace(/\s+/g, " ").trim()} ${verse.replace(/\s+/g, "")}`;
}
function mergeVision(base, vision) {
	if (!vision) return base;
	const next = {
		...base,
		enhancement: { ...base.enhancement }
	};
	if (typeof vision.subjectX === "number") next.subject = {
		...next.subject,
		x: clamp(vision.subjectX, .15, .85)
	};
	if (typeof vision.subjectY === "number") next.subject = {
		...next.subject,
		y: clamp(vision.subjectY, .12, .8)
	};
	if (vision.textAnchor) next.textAnchor = vision.textAnchor;
	if (vision.textColor) next.textColor = vision.textColor;
	if (vision.overlayColor) next.overlayColor = vision.overlayColor;
	if (typeof vision.needsOverlay === "boolean") next.needsOverlay = vision.needsOverlay;
	if (typeof vision.overlayOpacity === "number") next.overlayOpacity = clamp(vision.overlayOpacity, .12, .62);
	if (vision.faceRegion) next.faceRegion = {
		x: clamp(vision.faceRegion.x, 0, .8),
		y: clamp(vision.faceRegion.y, 0, .8),
		w: clamp(vision.faceRegion.w, .12, .9),
		h: clamp(vision.faceRegion.h, .12, .9)
	};
	if (vision.enhancement) {
		const e = vision.enhancement;
		if (typeof e.brightness === "number") next.enhancement.brightness = clamp(e.brightness, -.18, .18);
		if (typeof e.contrast === "number") next.enhancement.contrast = clamp(e.contrast, -.08, .28);
		if (typeof e.saturation === "number") next.enhancement.saturation = clamp(e.saturation, -.12, .16);
		if (typeof e.temperature === "number") next.enhancement.temperature = clamp(e.temperature, -.2, .22);
		if (typeof e.vignette === "number") next.enhancement.vignette = clamp(e.vignette, 0, .42);
	}
	return next;
}
function buildVariations(input) {
	const parsed = parseVerse(input.verse);
	return [
		"classic",
		"modern",
		"cinematic"
	].map((kind) => buildVariation({
		kind,
		analysis: input.analysis,
		verseText: parsed.text || input.verse.trim(),
		reference: parsed.reference,
		canvasSizeId: input.canvasSizeId,
		customWidthIn: input.customWidthIn,
		customHeightIn: input.customHeightIn
	}));
}
function buildVariation(input) {
	const { kind, analysis } = input;
	const len = input.verseText.length;
	const lengthScale = len < 36 ? 1.32 : len < 80 ? 1.12 : len < 140 ? 1 : len < 220 ? .84 : .7;
	const titles = {
		classic: "Classic Christian",
		modern: "Modern Premium",
		cinematic: "Cinematic"
	};
	const crop = subjectSafeCrop(analysis, kind);
	const placement = placeText(analysis, kind);
	const overlay = overlayFor(analysis, kind, placement.anchor);
	const baseEnhance = analysis.enhancement;
	const enhance = kind === "cinematic" ? {
		brightness: baseEnhance.brightness - .03,
		contrast: clamp(baseEnhance.contrast + .1, -.08, .3),
		saturation: baseEnhance.saturation + .02,
		temperature: baseEnhance.temperature + .03,
		vignette: clamp(baseEnhance.vignette + .14, 0, .42)
	} : kind === "modern" ? {
		brightness: baseEnhance.brightness + .02,
		contrast: baseEnhance.contrast * .7,
		saturation: baseEnhance.saturation * .7,
		temperature: baseEnhance.temperature * .6,
		vignette: clamp(baseEnhance.vignette * .45, 0, .18)
	} : {
		brightness: baseEnhance.brightness,
		contrast: baseEnhance.contrast + .03,
		saturation: baseEnhance.saturation,
		temperature: baseEnhance.temperature + .02,
		vignette: baseEnhance.vignette
	};
	const lightText = isLightColor(analysis.textColor);
	const textColor = kind === "modern" && lightText ? "#f7f3ea" : analysis.textColor;
	const classicSize = .052 * lengthScale;
	const modernSize = .036 * lengthScale;
	const cinematicSize = .058 * lengthScale;
	return {
		id: uid(),
		variation: kind,
		title: titles[kind],
		verseText: input.verseText,
		reference: input.reference,
		fontId: kind === "classic" ? "cormorant" : kind === "modern" ? "outfit" : "playfair",
		fontWeight: kind === "modern" ? 400 : 500,
		italic: kind === "classic",
		fontSize: kind === "classic" ? classicSize : kind === "modern" ? modernSize : cinematicSize,
		letterSpacing: kind === "modern" ? .04 : kind === "classic" ? .02 : .012,
		lineHeight: kind === "modern" ? 1.42 : 1.32,
		textAlign: placement.align,
		textColor,
		textOpacity: .96,
		textX: placement.x,
		textY: placement.y,
		textWidth: placement.width,
		textShadow: lightText ? {
			blur: kind === "cinematic" ? 18 : 12,
			opacity: .45,
			y: 2
		} : {
			blur: 0,
			opacity: 0,
			y: 0
		},
		textOutline: analysis.needsOverlay && !lightText ? {
			width: .8,
			color: "rgba(255,255,255,0.28)"
		} : lightText && kind === "cinematic" ? {
			width: .6,
			color: "rgba(18,14,10,0.35)"
		} : null,
		overlay,
		image: {
			cropX: crop.x,
			cropY: crop.y,
			zoom: crop.zoom,
			brightness: enhance.brightness,
			contrast: enhance.contrast,
			saturation: enhance.saturation,
			temperature: enhance.temperature,
			vignette: enhance.vignette
		},
		canvasSizeId: input.canvasSizeId,
		customWidthIn: input.customWidthIn,
		customHeightIn: input.customHeightIn
	};
}
function subjectSafeCrop(analysis, kind) {
	let x = analysis.subject.x;
	let y = analysis.subject.y;
	if (analysis.faceRegion) {
		x = analysis.faceRegion.x + analysis.faceRegion.w / 2;
		y = analysis.faceRegion.y + analysis.faceRegion.h / 2;
	}
	if (analysis.textAnchor === "bottom") y = clamp(y - .04, .28, .55);
	if (analysis.textAnchor === "top") y = clamp(y + .04, .4, .7);
	if (analysis.textAnchor === "left") x = clamp(x + .06, .4, .7);
	if (analysis.textAnchor === "right") x = clamp(x - .06, .3, .6);
	const zoom = kind === "cinematic" ? 1.12 : kind === "modern" ? 1.02 : 1.06;
	return {
		x: clamp(x, .28, .72),
		y: clamp(y, .28, .68),
		zoom
	};
}
function placeText(analysis, kind) {
	const anchor = analysis.textAnchor;
	if (kind === "modern") {
		if (anchor === "left") return {
			x: .28,
			y: .62,
			width: .5,
			align: "left",
			anchor
		};
		if (anchor === "right") return {
			x: .72,
			y: .62,
			width: .5,
			align: "right",
			anchor
		};
		if (anchor === "top") return {
			x: .5,
			y: .18,
			width: .72,
			align: "left",
			anchor
		};
		return {
			x: .5,
			y: .84,
			width: .78,
			align: "left",
			anchor
		};
	}
	if (kind === "cinematic") {
		if (anchor === "top") return {
			x: .5,
			y: .2,
			width: .8,
			align: "center",
			anchor
		};
		return {
			x: .5,
			y: .82,
			width: .82,
			align: "center",
			anchor: "bottom"
		};
	}
	if (anchor === "top") return {
		x: .5,
		y: .2,
		width: .76,
		align: "center",
		anchor
	};
	if (anchor === "left") return {
		x: .3,
		y: .78,
		width: .52,
		align: "left",
		anchor
	};
	if (anchor === "right") return {
		x: .7,
		y: .78,
		width: .52,
		align: "right",
		anchor
	};
	return {
		x: .5,
		y: .82,
		width: .78,
		align: "center",
		anchor
	};
}
function overlayFor(analysis, kind, anchor) {
	const color = analysis.overlayColor;
	if (kind === "modern" && !analysis.needsOverlay) return {
		kind: "none",
		color,
		opacity: 0
	};
	let overlayKind = "bottom-gradient";
	if (anchor === "top") overlayKind = "top-gradient";
	else if (anchor === "left") overlayKind = "left-gradient";
	else if (anchor === "right") overlayKind = "right-gradient";
	else overlayKind = "bottom-gradient";
	if (kind === "modern" && analysis.needsOverlay) return {
		kind: "soft-panel",
		color,
		opacity: clamp(analysis.overlayOpacity * .7, .16, .4)
	};
	const boost = kind === "cinematic" ? 1.15 : 1;
	if (!(kind === "cinematic" || analysis.needsOverlay || analysis.meanLuma > .55) && kind === "classic") return {
		kind: overlayKind,
		color,
		opacity: .22
	};
	return {
		kind: overlayKind,
		color,
		opacity: clamp(analysis.overlayOpacity * boost, .2, .58)
	};
}
function isLightColor(hex) {
	const n = hex.replace("#", "");
	if (n.length < 6) return true;
	const r = parseInt(n.slice(0, 2), 16);
	const g = parseInt(n.slice(2, 4), 16);
	const b = parseInt(n.slice(4, 6), 16);
	return (.2126 * r + .7152 * g + .0722 * b) / 255 > .6;
}
function cloneDesign(design) {
	return {
		...design,
		textShadow: { ...design.textShadow },
		textOutline: design.textOutline ? { ...design.textOutline } : null,
		overlay: { ...design.overlay },
		image: { ...design.image }
	};
}
var CANVAS_FONTS = [
	{
		id: "cormorant",
		family: "Cormorant Garamond",
		label: "Cormorant",
		category: "elegant-serif",
		weights: [
			400,
			500,
			600,
			700
		]
	},
	{
		id: "playfair",
		family: "Playfair Display",
		label: "Playfair",
		category: "editorial",
		weights: [
			400,
			500,
			600
		]
	},
	{
		id: "cinzel",
		family: "Cinzel",
		label: "Cinzel",
		category: "modern-serif",
		weights: [
			400,
			500,
			600
		]
	},
	{
		id: "baskerville",
		family: "Libre Baskerville",
		label: "Baskerville",
		category: "elegant-serif",
		weights: [400, 700]
	},
	{
		id: "outfit",
		family: "Outfit",
		label: "Outfit",
		category: "sans",
		weights: [
			300,
			400,
			500,
			600
		]
	}
];
var FONT_LOAD_SPECS = [
	"500 64px \"Cormorant Garamond\"",
	"italic 500 64px \"Cormorant Garamond\"",
	"500 64px \"Playfair Display\"",
	"italic 400 64px \"Playfair Display\"",
	"500 64px \"Cinzel\"",
	"400 64px \"Libre Baskerville\"",
	"italic 400 64px \"Libre Baskerville\"",
	"400 64px \"Outfit\"",
	"500 64px \"Outfit\""
];
var fontsPromise = null;
function ensureCanvasFonts() {
	if (typeof document === "undefined") return Promise.resolve();
	if (!fontsPromise) fontsPromise = (async () => {
		try {
			await document.fonts.ready;
			await Promise.all(FONT_LOAD_SPECS.map((spec) => document.fonts.load(spec)));
		} catch {}
	})();
	return fontsPromise;
}
function fontById(id) {
	return CANVAS_FONTS.find((f) => f.id === id) ?? CANVAS_FONTS[0];
}
var imageCache = /* @__PURE__ */ new Map();
function loadImage(src) {
	const cached = imageCache.get(src);
	if (cached && cached.complete && cached.naturalWidth > 0) return Promise.resolve(cached);
	return new Promise((resolve, reject) => {
		const img = new Image();
		if (!src.startsWith("blob:") && !src.startsWith("data:")) img.crossOrigin = "anonymous";
		img.onload = () => {
			imageCache.set(src, img);
			resolve(img);
		};
		img.onerror = () => reject(/* @__PURE__ */ new Error("Could not load the image."));
		img.src = src;
	});
}
function getPrintPixels(design, dpi) {
	const size = getCanvasSize(design.canvasSizeId, design.customWidthIn, design.customHeightIn);
	return {
		width: Math.round(size.widthIn * dpi),
		height: Math.round(size.heightIn * dpi)
	};
}
async function renderDesign(canvas, design, imageSrc, options = {}) {
	await ensureCanvasFonts();
	const img = await loadImage(imageSrc);
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	paintDesign(ctx, canvas.width, canvas.height, design, img, options.guides);
}
function paintDesign(ctx, width, height, design, img, guides = false) {
	ctx.save();
	ctx.clearRect(0, 0, width, height);
	ctx.fillStyle = "#120e0a";
	ctx.fillRect(0, 0, width, height);
	drawPhoto(ctx, width, height, design, img);
	drawTemperature(ctx, width, height, design.image.temperature);
	drawVignette(ctx, width, height, design.image.vignette);
	drawOverlay(ctx, width, height, design);
	const block = drawVerse(ctx, width, height, design);
	if (guides && block) {
		const margin = .08;
		ctx.save();
		ctx.strokeStyle = "rgba(244,239,230,0.28)";
		ctx.setLineDash([Math.max(4, width * .008), Math.max(4, width * .008)]);
		ctx.lineWidth = Math.max(1, width * .0012);
		ctx.strokeRect(width * margin, height * margin, width * (1 - margin * 2), height * (1 - margin * 2));
		ctx.restore();
	}
	ctx.restore();
}
function drawPhoto(ctx, width, height, design, img) {
	const { zoom, cropX, cropY, brightness, contrast, saturation } = design.image;
	const scale = Math.max(width / img.naturalWidth, height / img.naturalHeight) * zoom;
	const dw = img.naturalWidth * scale;
	const dh = img.naturalHeight * scale;
	let dx = width / 2 - cropX * dw;
	let dy = height / 2 - cropY * dh;
	dx = Math.min(0, Math.max(width - dw, dx));
	dy = Math.min(0, Math.max(height - dh, dy));
	ctx.filter = `brightness(${1 + brightness}) contrast(${1 + contrast}) saturate(${1 + saturation})`;
	ctx.drawImage(img, dx, dy, dw, dh);
	ctx.filter = "none";
}
function drawTemperature(ctx, width, height, temperature) {
	if (Math.abs(temperature) < .01) return;
	ctx.save();
	ctx.globalCompositeOperation = "soft-light";
	ctx.globalAlpha = Math.min(.5, Math.abs(temperature) * .9);
	ctx.fillStyle = temperature > 0 ? "#e8a15a" : "#6a8ec8";
	ctx.fillRect(0, 0, width, height);
	ctx.restore();
}
function drawVignette(ctx, width, height, amount) {
	if (amount <= .01) return;
	const g = ctx.createRadialGradient(width * .5, height * .42, Math.min(width, height) * .18, width * .5, height * .5, Math.max(width, height) * .72);
	g.addColorStop(0, "rgba(8,6,4,0)");
	g.addColorStop(1, `rgba(8,6,4,${clamp(amount, 0, .7)})`);
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, width, height);
}
function drawOverlay(ctx, width, height, design) {
	const { kind, color, opacity } = design.overlay;
	if (kind === "none" || opacity <= .01) return;
	ctx.save();
	ctx.globalAlpha = opacity;
	if (kind === "soft-panel") {
		const padX = width * design.textWidth * .08;
		const boxW = width * design.textWidth + padX * 2;
		const boxX = design.textAlign === "left" ? width * design.textX - padX : design.textAlign === "right" ? width * design.textX - boxW + padX : width * design.textX - boxW / 2;
		const boxH = height * .28;
		roundRect(ctx, boxX, height * design.textY - boxH * .55, boxW, boxH, Math.min(width, height) * .02);
		ctx.fillStyle = color;
		ctx.fill();
		ctx.restore();
		return;
	}
	let gradient;
	if (kind === "top-gradient") {
		gradient = ctx.createLinearGradient(0, 0, 0, height * .55);
		gradient.addColorStop(0, color);
		gradient.addColorStop(1, hexAlpha(color, 0));
	} else if (kind === "left-gradient") {
		gradient = ctx.createLinearGradient(0, 0, width * .62, 0);
		gradient.addColorStop(0, color);
		gradient.addColorStop(1, hexAlpha(color, 0));
	} else if (kind === "right-gradient") {
		gradient = ctx.createLinearGradient(width, 0, width * .38, 0);
		gradient.addColorStop(0, color);
		gradient.addColorStop(1, hexAlpha(color, 0));
	} else {
		gradient = ctx.createLinearGradient(0, height * .42, 0, height);
		gradient.addColorStop(0, hexAlpha(color, 0));
		gradient.addColorStop(1, color);
	}
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, width, height);
	ctx.restore();
}
function drawVerse(ctx, width, height, design) {
	const text = design.verseText.trim();
	if (!text && !design.reference.trim()) return null;
	const unit = Math.min(width, height);
	const font = fontById(design.fontId);
	const fontSize = Math.max(10, design.fontSize * unit);
	const maxWidth = width * design.textWidth;
	ctx.font = `${design.italic ? "italic " : ""}${design.fontWeight} ${fontSize}px "${font.family}", serif`;
	ctx.textAlign = design.textAlign;
	ctx.textBaseline = "top";
	setLetterSpacing(ctx, `${design.letterSpacing * fontSize}px`);
	const lines = wrapText(ctx, text, maxWidth);
	const lineHeight = fontSize * design.lineHeight;
	const citation = design.reference.trim();
	const citeSize = Math.max(10, fontSize * .38);
	const citeGap = fontSize * .55;
	const ruleH = fontSize * .08;
	const blockH = lines.length * lineHeight + (citation ? citeGap + ruleH + citeSize * 1.2 : 0);
	const originX = width * design.textX;
	let top = height * design.textY - blockH / 2;
	const margin = height * .08;
	top = clamp(top, margin, height - margin - blockH);
	ctx.save();
	ctx.globalAlpha = design.textOpacity;
	if (design.textShadow.opacity > 0) {
		ctx.shadowColor = `rgba(8,6,4,${design.textShadow.opacity})`;
		ctx.shadowBlur = design.textShadow.blur * (unit / 900);
		ctx.shadowOffsetY = design.textShadow.y * (unit / 900);
	}
	ctx.fillStyle = design.textColor;
	if (design.textOutline) {
		ctx.strokeStyle = design.textOutline.color;
		ctx.lineWidth = design.textOutline.width * (unit / 700);
		ctx.lineJoin = "round";
	}
	for (let i = 0; i < lines.length; i++) {
		const y = top + i * lineHeight;
		const line = lines[i];
		if (design.textOutline) ctx.strokeText(line, originX, y);
		ctx.fillText(line, originX, y);
	}
	if (citation) {
		const citeY = top + lines.length * lineHeight + citeGap;
		const ruleW = Math.min(maxWidth * .18, unit * .12);
		const ruleX = design.textAlign === "left" ? originX : design.textAlign === "right" ? originX - ruleW : originX - ruleW / 2;
		ctx.shadowBlur = 0;
		ctx.globalAlpha = design.textOpacity * .8;
		ctx.fillRect(ruleX, citeY - ruleH, ruleW, Math.max(1, unit * .0014));
		ctx.font = `500 ${citeSize}px "Cinzel", "Outfit", sans-serif`;
		setLetterSpacing(ctx, `${citeSize * .22}px`);
		ctx.fillStyle = design.textColor;
		ctx.fillText(citation.toUpperCase(), originX, citeY + ruleH * 2);
	}
	ctx.restore();
	setLetterSpacing(ctx, "0px");
	return {
		top,
		height: blockH,
		width: maxWidth
	};
}
function wrapText(ctx, text, maxWidth) {
	if (!text) return [];
	const paragraphs = text.split(/\n+/);
	const lines = [];
	for (const para of paragraphs) {
		const words = para.trim().split(/\s+/).filter(Boolean);
		let current = "";
		for (const word of words) {
			const next = current ? `${current} ${word}` : word;
			if (ctx.measureText(next).width > maxWidth && current) {
				lines.push(current);
				current = word;
			} else current = next;
		}
		if (current) lines.push(current);
	}
	return lines.length ? lines : [text];
}
function setLetterSpacing(ctx, value) {
	const writable = ctx;
	if (typeof writable.letterSpacing === "string" || "letterSpacing" in ctx) writable.letterSpacing = value;
}
function hexAlpha(hex, a) {
	const n = hex.replace("#", "");
	if (n.length < 6) return `rgba(18,14,10,${a})`;
	return `rgba(${parseInt(n.slice(0, 2), 16)},${parseInt(n.slice(2, 4), 16)},${parseInt(n.slice(4, 6), 16)},${a})`;
}
function roundRect(ctx, x, y, w, h, r) {
	const radius = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + radius, y);
	ctx.arcTo(x + w, y, x + w, y + h, radius);
	ctx.arcTo(x + w, y + h, x, y + h, radius);
	ctx.arcTo(x, y + h, x, y, radius);
	ctx.arcTo(x, y, x + w, y, radius);
	ctx.closePath();
}
var GRID = 3;
var SAMPLE = 96;
function luma(r, g, b) {
	return (.2126 * r + .7152 * g + .0722 * b) / 255;
}
function sat(r, g, b) {
	const max = Math.max(r, g, b) / 255;
	const min = Math.min(r, g, b) / 255;
	const l = (max + min) / 2;
	if (max === min) return 0;
	const d = max - min;
	return l > .5 ? d / (2 - max - min) : d / (max + min);
}
function analyzeImage(img, preferredSizeId) {
	const canvas = document.createElement("canvas");
	canvas.width = SAMPLE;
	canvas.height = SAMPLE;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) return fallbackAnalysis(img, preferredSizeId);
	ctx.drawImage(img, 0, 0, SAMPLE, SAMPLE);
	const { data } = ctx.getImageData(0, 0, SAMPLE, SAMPLE);
	const cellW = SAMPLE / GRID;
	const cells = Array.from({ length: 9 }, () => ({
		luma: 0,
		variance: 0,
		edge: 0,
		sat: 0
	}));
	const cellLumas = Array.from({ length: 9 }, () => []);
	let lumaSum = 0;
	let satSum = 0;
	const lumas = [];
	for (let y = 0; y < SAMPLE; y++) for (let x = 0; x < SAMPLE; x++) {
		const i = (y * SAMPLE + x) * 4;
		const r = data[i] ?? 0;
		const g = data[i + 1] ?? 0;
		const b = data[i + 2] ?? 0;
		const Y = luma(r, g, b);
		const S = sat(r, g, b);
		lumaSum += Y;
		satSum += S;
		lumas.push(Y);
		const col = Math.min(2, Math.floor(x / cellW));
		const idx = Math.min(2, Math.floor(y / cellW)) * GRID + col;
		const cell = cells[idx];
		cell.luma += Y;
		cell.sat += S;
		cellLumas[idx].push(Y);
		if (x < 95 && y < 95) {
			const iRight = (y * SAMPLE + (x + 1)) * 4;
			const iDown = ((y + 1) * SAMPLE + x) * 4;
			const yr = luma(data[iRight] ?? 0, data[iRight + 1] ?? 0, data[iRight + 2] ?? 0);
			const yd = luma(data[iDown] ?? 0, data[iDown + 1] ?? 0, data[iDown + 2] ?? 0);
			cell.edge += Math.abs(Y - yr) + Math.abs(Y - yd);
		}
	}
	const n = 9216;
	const meanLuma = lumaSum / n;
	const meanSat = satSum / n;
	let varSum = 0;
	for (const Y of lumas) varSum += (Y - meanLuma) ** 2;
	const contrast = Math.sqrt(varSum / n);
	for (let i = 0; i < cells.length; i++) {
		const samples = cellLumas[i];
		const cell = cells[i];
		const count = samples.length || 1;
		cell.luma /= count;
		cell.sat /= count;
		const m = cell.luma;
		let v = 0;
		for (const Y of samples) v += (Y - m) ** 2;
		cell.variance = v / count;
		cell.edge /= count;
	}
	let subjectIdx = 0;
	let maxEdge = -1;
	for (let i = 0; i < cells.length; i++) {
		const score = cells[i].edge * 1.15 + cells[i].variance;
		if (score > maxEdge) {
			maxEdge = score;
			subjectIdx = i;
		}
	}
	const subjectCol = subjectIdx % GRID;
	const subjectRow = Math.floor(subjectIdx / GRID);
	const textAnchor = pickTextAnchor(subjectRow, subjectCol, cells);
	const textCell = cellForAnchor(textAnchor, cells);
	const needsOverlay = textCell.variance > .012 || textCell.edge > .045;
	const overlayOpacity = clamp(.22 + textCell.variance * 4 + textCell.edge * 2, .18, .55);
	const textOnDark = textCell.luma < .52;
	const textColor = textOnDark ? "#f4efe6" : "#1c1812";
	const overlayColor = textOnDark ? "#120e0a" : "#f4efe6";
	const enhancement = {
		brightness: 0,
		contrast: 0,
		saturation: 0,
		temperature: 0,
		vignette: .12
	};
	if (contrast < .14) enhancement.contrast += .16;
	else if (contrast < .18) enhancement.contrast += .08;
	else if (contrast > .32) enhancement.contrast -= .05;
	if (meanLuma > .72) enhancement.brightness -= .1;
	else if (meanLuma > .62) enhancement.brightness -= .04;
	else if (meanLuma < .26) enhancement.brightness += .1;
	else if (meanLuma < .34) enhancement.brightness += .05;
	if (meanSat < .12) enhancement.saturation += .08;
	else if (meanSat > .48) enhancement.saturation -= .06;
	if (meanLuma < .42) enhancement.temperature += .06;
	enhancement.vignette = clamp(.1 + (.22 - contrast), .08, .28);
	const aspect = img.width / img.height || .75;
	const recommended = pickAutoSize(aspect);
	return {
		width: img.width,
		height: img.height,
		aspect,
		meanLuma,
		contrast,
		saturation: meanSat,
		grid: cells,
		subject: {
			col: subjectCol,
			row: subjectRow,
			x: (subjectCol + .5) / GRID,
			y: (subjectRow + .5) / GRID
		},
		textAnchor,
		textColor,
		overlayColor,
		needsOverlay,
		overlayOpacity,
		recommendedSizeId: preferredSizeId === "auto" ? recommended.id : preferredSizeId,
		faceRegion: null,
		enhancement
	};
}
function pickTextAnchor(subjectRow, subjectCol, cells) {
	if (subjectRow <= 1) return "bottom";
	if (subjectRow === 2) return "top";
	const leftBusy = (cells[0].variance + cells[3].variance + cells[6].variance) / 3;
	const rightBusy = (cells[2].variance + cells[5].variance + cells[8].variance) / 3;
	if (subjectCol === 0 && rightBusy < leftBusy) return "right";
	if (subjectCol === 2 && leftBusy < rightBusy) return "left";
	return "bottom";
}
function cellForAnchor(anchor, cells) {
	if (anchor === "top") return averageCells([
		cells[0],
		cells[1],
		cells[2]
	]);
	if (anchor === "left") return averageCells([
		cells[0],
		cells[3],
		cells[6]
	]);
	if (anchor === "right") return averageCells([
		cells[2],
		cells[5],
		cells[8]
	]);
	return averageCells([
		cells[6],
		cells[7],
		cells[8]
	]);
}
function averageCells(list) {
	const n = list.length || 1;
	return {
		luma: list.reduce((s, c) => s + c.luma, 0) / n,
		variance: list.reduce((s, c) => s + c.variance, 0) / n,
		edge: list.reduce((s, c) => s + c.edge, 0) / n,
		sat: list.reduce((s, c) => s + c.sat, 0) / n
	};
}
function fallbackAnalysis(img, preferredSizeId) {
	const aspect = img.width / img.height || .75;
	return {
		width: img.width,
		height: img.height,
		aspect,
		meanLuma: .4,
		contrast: .18,
		saturation: .22,
		grid: Array.from({ length: 9 }, () => ({
			luma: .4,
			variance: .02,
			edge: .03,
			sat: .22
		})),
		subject: {
			col: 1,
			row: 1,
			x: .5,
			y: .42
		},
		textAnchor: "bottom",
		textColor: "#f4efe6",
		overlayColor: "#120e0a",
		needsOverlay: true,
		overlayOpacity: .36,
		recommendedSizeId: preferredSizeId === "auto" ? pickAutoSize(aspect).id : preferredSizeId,
		faceRegion: null,
		enhancement: {
			brightness: 0,
			contrast: .08,
			saturation: .04,
			temperature: .04,
			vignette: .16
		}
	};
}
function downsampleToJpeg(img, maxDim = 512, quality = .72) {
	const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
	const w = Math.max(1, Math.round(img.width * scale));
	const h = Math.max(1, Math.round(img.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) return "";
	ctx.drawImage(img, 0, 0, w, h);
	return canvas.toDataURL("image/jpeg", quality);
}
var useStudio = create((set, get) => ({
	step: "compose",
	imageSrc: null,
	imageOrigin: null,
	verse: "",
	canvasSizeId: "auto",
	customWidthIn: 16,
	customHeightIn: 20,
	analysis: null,
	variations: [],
	selectedId: null,
	history: [],
	future: [],
	designBusy: false,
	designStatus: "",
	exportBusy: false,
	generateOpen: false,
	editMode: "text",
	setStep: (step) => set({ step }),
	setVerse: (verse) => set({ verse }),
	setCanvasSizeId: (canvasSizeId) => set({ canvasSizeId }),
	setCustomSize: (customWidthIn, customHeightIn) => set({
		customWidthIn,
		customHeightIn
	}),
	setImage: (imageSrc, imageOrigin) => set({
		imageSrc,
		imageOrigin
	}),
	clearImage: () => set({
		imageSrc: null,
		imageOrigin: null
	}),
	setDesigning: (designStatus) => set({
		step: "designing",
		designBusy: true,
		designStatus
	}),
	finishDesign: ({ analysis, variations, canvasSizeId }) => set({
		analysis,
		variations,
		canvasSizeId,
		selectedId: variations[0]?.id ?? null,
		step: "gallery",
		designBusy: false,
		designStatus: "",
		history: [],
		future: []
	}),
	selectVariation: (selectedId) => set({
		selectedId,
		history: [],
		future: [],
		step: "editor"
	}),
	selectedDesign: () => {
		const { variations, selectedId } = get();
		return variations.find((v) => v.id === selectedId) ?? null;
	},
	patchDesign: (patch, commit = true) => {
		const { variations, selectedId, history } = get();
		const current = variations.find((v) => v.id === selectedId);
		if (!current) return;
		const next = {
			...cloneDesign(current),
			...patch,
			id: current.id
		};
		if (patch.image) next.image = {
			...current.image,
			...patch.image
		};
		if (patch.overlay) next.overlay = {
			...current.overlay,
			...patch.overlay
		};
		if (patch.textShadow) next.textShadow = {
			...current.textShadow,
			...patch.textShadow
		};
		set({
			variations: variations.map((v) => v.id === current.id ? next : v),
			history: commit ? [...history, cloneDesign(current)].slice(-40) : history,
			future: commit ? [] : get().future
		});
	},
	patchImage: (patch, commit = true) => {
		const current = get().selectedDesign();
		if (!current) return;
		get().patchDesign({ image: {
			...current.image,
			...patch
		} }, commit);
	},
	commit: () => {
		const current = get().selectedDesign();
		if (!current) return;
		set({
			history: [...get().history, cloneDesign(current)].slice(-40),
			future: []
		});
	},
	undo: () => {
		const { history, variations, selectedId, future } = get();
		const current = variations.find((v) => v.id === selectedId);
		const prev = history[history.length - 1];
		if (!current || !prev) return;
		set({
			history: history.slice(0, -1),
			future: [...future, cloneDesign(current)],
			variations: variations.map((v) => v.id === current.id ? {
				...cloneDesign(prev),
				id: current.id
			} : v)
		});
	},
	redo: () => {
		const { future, variations, selectedId, history } = get();
		const current = variations.find((v) => v.id === selectedId);
		const next = future[future.length - 1];
		if (!current || !next) return;
		set({
			future: future.slice(0, -1),
			history: [...history, cloneDesign(current)].slice(-40),
			variations: variations.map((v) => v.id === current.id ? {
				...cloneDesign(next),
				id: current.id
			} : v)
		});
	},
	setGenerateOpen: (generateOpen) => set({ generateOpen }),
	setExportBusy: (exportBusy) => set({ exportBusy }),
	setEditMode: (editMode) => set({ editMode }),
	resetToCompose: () => set({
		step: "compose",
		variations: [],
		selectedId: null,
		history: [],
		future: [],
		analysis: null,
		designBusy: false
	})
}));
var STATUS = [
	"Reading light and composition",
	"Protecting the subject",
	"Choosing type and placement",
	"Balancing contrast",
	"Setting print-safe margins",
	"Composing three variations"
];
async function runAutoDesign() {
	const studio = useStudio.getState();
	const { imageSrc, verse, canvasSizeId, customWidthIn, customHeightIn } = studio;
	if (!imageSrc || !verse.trim()) return;
	studio.setDesigning(STATUS[0]);
	const started = Date.now();
	let tick = 0;
	const timer = window.setInterval(() => {
		tick += 1;
		useStudio.setState({ designStatus: STATUS[tick % STATUS.length] });
	}, 700);
	try {
		const img = await loadImage(imageSrc);
		const local = analyzeImage(img, canvasSizeId);
		const sizeId = local.recommendedSizeId;
		const size = getCanvasSize(sizeId, customWidthIn, customHeightIn);
		let vision = null;
		try {
			const small = downsampleToJpeg(img, 480, .7);
			if (small) {
				const result = await Promise.race([analyzeLayout({ data: {
					imageDataUrl: small,
					verse: verse.trim(),
					canvasLabel: size.label
				} }), sleep(1e4).then(() => null)]);
				if (result && result.ok) vision = result.layout;
			}
		} catch {
			vision = null;
		}
		const analysis = mergeVision(local, vision);
		const variations = buildVariations({
			analysis,
			verse,
			canvasSizeId: sizeId,
			customWidthIn,
			customHeightIn
		});
		const elapsed = Date.now() - started;
		if (elapsed < 2400) await sleep(2400 - elapsed);
		window.clearInterval(timer);
		useStudio.getState().finishDesign({
			analysis,
			variations,
			canvasSizeId: sizeId
		});
	} catch (error) {
		window.clearInterval(timer);
		throw error;
	}
}
var SAMPLE_SCENES = [
	{
		id: "olive-grove",
		src: "/samples/olive-grove.jpg",
		label: "Olive grove"
	},
	{
		id: "dawn-lake",
		src: "/samples/dawn-lake.jpg",
		label: "Dawn lake"
	},
	{
		id: "chapel-light",
		src: "/samples/chapel-light.jpg",
		label: "Chapel light"
	}
];
var TEXT_COLOR_PRESETS = [
	{
		id: "cream",
		value: "#f4efe6",
		label: "Cream"
	},
	{
		id: "white",
		value: "#fbfaf7",
		label: "White"
	},
	{
		id: "gold",
		value: "#d4bc8a",
		label: "Gold"
	},
	{
		id: "ink",
		value: "#1c1812",
		label: "Ink"
	},
	{
		id: "charcoal",
		value: "#2b261f",
		label: "Charcoal"
	}
];
var VARIATION_META = {
	classic: {
		title: "Classic Christian",
		subtitle: "Elegant serif, balanced and timeless"
	},
	modern: {
		title: "Modern Premium",
		subtitle: "Quiet type, generous space"
	},
	cinematic: {
		title: "Cinematic",
		subtitle: "Dramatic light, editorial type"
	}
};
function ComposeScreen() {
	const inputRef = (0, import_react.useRef)(null);
	const imageSrc = useStudio((s) => s.imageSrc);
	const imageOrigin = useStudio((s) => s.imageOrigin);
	const verse = useStudio((s) => s.verse);
	const canvasSizeId = useStudio((s) => s.canvasSizeId);
	const customWidthIn = useStudio((s) => s.customWidthIn);
	const customHeightIn = useStudio((s) => s.customHeightIn);
	const setImage = useStudio((s) => s.setImage);
	const clearImage = useStudio((s) => s.clearImage);
	const setVerse = useStudio((s) => s.setVerse);
	const setCanvasSizeId = useStudio((s) => s.setCanvasSizeId);
	const setCustomSize = useStudio((s) => s.setCustomSize);
	const setGenerateOpen = useStudio((s) => s.setGenerateOpen);
	function onFile(file) {
		if (!file) return;
		if (!file.type.startsWith("image/")) {
			toast.error("Please choose a JPG, PNG, or WebP photo.");
			return;
		}
		const url = URL.createObjectURL(file);
		setImage(url, "upload");
	}
	async function onAutoDesign() {
		if (!imageSrc) {
			toast.error("Upload a photo or choose a scene first.");
			return;
		}
		if (!verse.trim()) {
			toast.error("Add a Bible verse to place on the canvas.");
			return;
		}
		try {
			await runAutoDesign();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Auto Design failed.");
			useStudio.getState().resetToCompose();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-lg flex-col gap-7 px-5 pb-16 pt-8 sm:pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "reveal flex flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrossMark, { className: "mb-4 h-8 w-6 text-gold" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-classical text-[0.68rem] font-medium tracking-[0.38em] text-gold",
						children: "CHRISTIAN CANVAS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-[2.35rem] font-medium leading-[1.1] text-cream sm:text-5xl",
						children: "Designer AI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-pretty text-sm leading-relaxed text-muted",
						children: "Upload a photo, add a verse, and Auto Design builds a print-ready wall canvas for you."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "reveal-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Upload photo" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						type: "file",
						accept: "image/*",
						className: "sr-only",
						onChange: (event) => {
							onFile(event.target.files?.[0]);
							event.currentTarget.value = "";
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => inputRef.current?.click(),
						className: cn("group relative flex w-full overflow-hidden rounded-xl bg-bg-elevated text-left shadow-[0_0_0_1px_rgba(176,141,87,0.28)] transition-shadow duration-[var(--motion-quick)] hover:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]", imageSrc ? "aspect-[4/5] sm:aspect-[4/3]" : "min-h-44 items-center justify-center"),
						children: imageSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: imageSrc,
							alt: "Selected artwork",
							className: "h-full w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "absolute inset-x-3 bottom-3 flex items-center justify-center gap-2 rounded-md bg-ink/80 px-3 py-2 text-xs tracking-[0.12em] text-cream",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }), "Change photo"]
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-col items-center gap-3 px-6 py-10 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-12 items-center justify-center rounded-md bg-bg-subtle text-gold",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-cream",
									children: "Tap to upload a photo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-subtle",
									children: "Jesus, Christian artwork, or a quiet scene"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2 overflow-x-auto pb-1",
						children: [SAMPLE_SCENES.map((scene) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setImage(scene.src, "sample"),
							className: cn("relative h-16 w-16 shrink-0 overflow-hidden rounded-md shadow-[0_0_0_1px_rgba(244,239,230,0.12)]", imageSrc === scene.src && "shadow-[0_0_0_1px_rgba(176,141,87,0.9)]"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: scene.src,
								alt: scene.label,
								className: "h-full w-full object-cover"
							})
						}, scene.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setGenerateOpen(true),
							className: "flex h-16 w-16 shrink-0 flex-col items-center justify-center gap-1 rounded-md bg-bg-elevated text-gold shadow-[0_0_0_1px_rgba(176,141,87,0.35)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[0.6rem] tracking-[0.08em]",
								children: "Original"
							})]
						})]
					}),
					imageOrigin === "upload" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs leading-relaxed text-subtle",
						children: "Make sure you have permission to use this image commercially."
					}) : null,
					imageSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: clearImage,
						className: "mt-2 text-xs text-muted underline-offset-4 hover:text-cream hover:underline",
						children: "Remove photo"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "reveal-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Paste Bible verse" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: verse,
						onChange: (event) => setVerse(event.target.value),
						rows: 5,
						placeholder: "For God so loved the world… John 3:16",
						className: "w-full resize-none rounded-lg bg-bg-elevated px-4 py-3 text-sm leading-relaxed text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none placeholder:text-subtle focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex gap-2 overflow-x-auto pb-1",
						children: SAMPLE_VERSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setVerse(formatVerseInput(item.text, item.reference)),
							className: "h-9 shrink-0 rounded-full px-3 text-xs text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)] hover:text-cream",
							children: item.reference
						}, item.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "reveal-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: "Canvas size" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: CANVAS_SIZES.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCanvasSizeId(size.id),
							className: cn("h-10 rounded-full px-3.5 text-xs tracking-[0.04em] transition-colors", canvasSizeId === size.id ? "bg-cream text-ink" : "text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)] hover:text-cream"),
							children: size.label
						}, size.id))
					}),
					canvasSizeId === "custom" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "Width (in)",
							value: customWidthIn,
							onChange: (n) => setCustomSize(n, customHeightIn)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							label: "Height (in)",
							value: customHeightIn,
							onChange: (n) => setCustomSize(customWidthIn, n)
						})]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "reveal-5 sticky bottom-4 z-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "h-12 w-full rounded-lg font-medium tracking-[0.18em]",
					onClick: () => void onAutoDesign(),
					children: "AUTO DESIGN"
				})
			})
		]
	});
}
function FieldLabel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 font-classical text-[0.62rem] font-medium tracking-[0.28em] text-gold",
		children: children.toUpperCase()
	});
}
function NumberField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1.5 text-xs text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "number",
			min: 6,
			max: 40,
			step: .01,
			value,
			onChange: (event) => onChange(Number(event.target.value)),
			className: "h-11 rounded-md bg-bg-elevated px-3 text-sm text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
		})]
	});
}
function DesigningScreen() {
	const imageSrc = useStudio((s) => s.imageSrc);
	const status = useStudio((s) => s.designStatus);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-[100dvh] w-full max-w-lg flex-col items-center justify-center px-6 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-full max-w-xs overflow-hidden rounded-xl bg-bg-elevated shadow-[0_0_0_1px_rgba(176,141,87,0.35)]",
				children: [
					imageSrc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: imageSrc,
						alt: "",
						className: "aspect-[3/4] w-full object-cover opacity-70"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-[3/4] w-full bg-bg-subtle" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[linear-gradient(to_bottom,rgba(18,16,12,0.2),rgba(18,16,12,0.55))]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-line" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrossMark, { className: "mt-8 h-7 w-5 text-gold" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-classical text-[0.68rem] tracking-[0.32em] text-gold",
				children: "AUTO DESIGN"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-center font-display text-2xl text-cream",
				children: status || "Composing your canvas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xs text-center text-sm leading-relaxed text-muted",
				children: "Choosing crop, type, color, and print-safe margins from your photo."
			})
		]
	});
}
function Slider({ value, min = 0, max = 1, step = .01, onValueChange, className, ariaLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex h-11 w-full touch-none select-none items-center", className),
		value: [value],
		min,
		max,
		step,
		onValueChange: (v) => onValueChange(v[0] ?? min),
		"aria-label": ariaLabel,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1 w-full grow rounded-full bg-bg-subtle",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-gold" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-cream shadow-[0_0_0_1px_rgba(28,24,18,0.35)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60" })]
	});
}
function DesignCanvas({ design, imageSrc, className, guides = false, interactive = false, mode = "text", onDragStart, onTextDrag, onImageDrag }) {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const dragRef = (0, import_react.useRef)(null);
	const size = getCanvasSize(design.canvasSizeId, design.customWidthIn, design.customHeightIn);
	(0, import_react.useEffect)(() => {
		const wrap = wrapRef.current;
		const canvas = canvasRef.current;
		if (!wrap || !canvas) return;
		let cancelled = false;
		const draw = async () => {
			const rect = wrap.getBoundingClientRect();
			if (rect.width < 4 || rect.height < 4) return;
			const dpr = Math.min(2.5, window.devicePixelRatio || 1);
			canvas.width = Math.round(rect.width * dpr);
			canvas.height = Math.round(rect.height * dpr);
			canvas.style.width = `${rect.width}px`;
			canvas.style.height = `${rect.height}px`;
			try {
				await renderDesign(canvas, design, imageSrc, { guides });
			} catch {
				if (!cancelled) {
					const ctx = canvas.getContext("2d");
					if (ctx) {
						ctx.fillStyle = "#1c1812";
						ctx.fillRect(0, 0, canvas.width, canvas.height);
					}
				}
			}
		};
		const observer = new ResizeObserver(() => {
			draw();
		});
		observer.observe(wrap);
		draw();
		return () => {
			cancelled = true;
			observer.disconnect();
		};
	}, [
		design,
		imageSrc,
		guides
	]);
	function clientToNorm(event) {
		const canvas = canvasRef.current;
		if (!canvas) return {
			x: 0,
			y: 0
		};
		const rect = canvas.getBoundingClientRect();
		return {
			x: (event.clientX - rect.left) / rect.width,
			y: (event.clientY - rect.top) / rect.height
		};
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: wrapRef,
		className: cn("relative overflow-hidden bg-ink", className),
		style: { aspectRatio: `${size.widthIn} / ${size.heightIn}` },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: cn("block h-full w-full touch-none", interactive && (mode === "text" ? "cursor-move" : "cursor-grab active:cursor-grabbing")),
			onPointerDown: (event) => {
				if (!interactive) return;
				const pos = clientToNorm(event);
				dragRef.current = {
					pointerId: event.pointerId,
					startX: pos.x,
					startY: pos.y,
					origX: mode === "text" ? design.textX : design.image.cropX,
					origY: mode === "text" ? design.textY : design.image.cropY
				};
				onDragStart?.();
				event.currentTarget.setPointerCapture(event.pointerId);
			},
			onPointerMove: (event) => {
				const drag = dragRef.current;
				if (!drag || event.pointerId !== drag.pointerId) return;
				const pos = clientToNorm(event);
				const dx = pos.x - drag.startX;
				const dy = pos.y - drag.startY;
				if (mode === "text") onTextDrag?.(clamp01(drag.origX + dx, .16, .84), clamp01(drag.origY + dy, .14, .9));
				else onImageDrag?.(clamp01(drag.origX - dx * .55, .2, .8), clamp01(drag.origY - dy * .55, .2, .8));
			},
			onPointerUp: (event) => {
				if (!dragRef.current) return;
				dragRef.current = null;
				event.currentTarget.releasePointerCapture(event.pointerId);
			},
			onPointerCancel: () => {
				dragRef.current = null;
			}
		})
	});
}
function clamp01(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
async function renderExportCanvas(design, imageSrc) {
	await ensureCanvasFonts();
	const size = getCanvasSize(design.canvasSizeId, design.customWidthIn, design.customHeightIn);
	const { width, height } = getPrintPixels(design, exportDpi(size.widthIn, size.heightIn));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not create an export canvas.");
	paintDesign(ctx, width, height, design, await loadImage(imageSrc), false);
	return {
		canvas,
		size
	};
}
function toBlob(canvas, type, quality) {
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => {
			if (!blob) reject(/* @__PURE__ */ new Error("Could not export the canvas."));
			else resolve(blob);
		}, type, quality);
	});
}
async function exportPng(design, imageSrc) {
	const { canvas, size } = await renderExportCanvas(design, imageSrc);
	downloadBlob(await toBlob(canvas, "image/png"), `${exportBasename(size)}.png`);
}
async function exportJpg(design, imageSrc) {
	const { canvas, size } = await renderExportCanvas(design, imageSrc);
	downloadBlob(await toBlob(canvas, "image/jpeg", .95), `${exportBasename(size)}.jpg`);
}
async function exportPdf(design, imageSrc) {
	const { canvas, size } = await renderExportCanvas(design, imageSrc);
	const dataUrl = canvas.toDataURL("image/jpeg", .93);
	const orientation = size.widthIn > size.heightIn ? "landscape" : "portrait";
	const pdf = new import_jspdf_node_min.jsPDF({
		orientation,
		unit: "in",
		format: [size.widthIn, size.heightIn],
		compress: true
	});
	pdf.addImage(dataUrl, "JPEG", 0, 0, size.widthIn, size.heightIn);
	pdf.save(`${exportBasename(size)}.pdf`);
}
function EditorScreen() {
	const imageSrc = useStudio((s) => s.imageSrc);
	const variations = useStudio((s) => s.variations);
	const selectedId = useStudio((s) => s.selectedId);
	const design = variations.find((v) => v.id === selectedId) ?? null;
	const history = useStudio((s) => s.history);
	const future = useStudio((s) => s.future);
	const editMode = useStudio((s) => s.editMode);
	const exportBusy = useStudio((s) => s.exportBusy);
	const [tab, setTab] = (0, import_react.useState)("type");
	const [exportOpen, setExportOpen] = (0, import_react.useState)(false);
	if (!design || !imageSrc) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-[100dvh] w-full max-w-6xl flex-col lg:flex-row",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center gap-1 px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => useStudio.setState({ step: "gallery" }),
							className: "flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated",
							"aria-label": "Back to designs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-display text-lg text-cream",
								children: VARIATION_META[design.variation].title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: ["Drag to move ", editMode === "text" ? "the verse" : "the crop"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => useStudio.getState().undo(),
							disabled: history.length === 0,
							className: "flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated disabled:opacity-30",
							"aria-label": "Undo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => useStudio.getState().redo(),
							disabled: future.length === 0,
							className: "flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated disabled:opacity-30",
							"aria-label": "Redo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo2, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							className: "ml-1",
							onClick: () => setExportOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Export"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-1 items-center justify-center px-4 pb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full max-w-md rounded-xl bg-bg-elevated p-2 shadow-[0_0_0_1px_rgba(176,141,87,0.35)] lg:max-w-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesignCanvas, {
							design,
							imageSrc,
							guides: true,
							interactive: true,
							mode: editMode,
							className: "rounded-lg",
							onDragStart: () => useStudio.getState().commit(),
							onTextDrag: (x, y) => {
								useStudio.getState().setEditMode("text");
								useStudio.getState().patchDesign({
									textX: x,
									textY: y
								}, false);
							},
							onImageDrag: (x, y) => {
								useStudio.getState().patchImage({
									cropX: x,
									cropY: y
								}, false);
							}
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "border-t border-border bg-bg-elevated lg:w-90 lg:border-l lg:border-t-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 px-4 pt-4",
					children: [
						"type",
						"image",
						"verse"
					].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setTab(id);
							if (id === "image") useStudio.getState().setEditMode("image");
							if (id === "type") useStudio.getState().setEditMode("text");
						},
						className: cn("h-10 flex-1 rounded-full text-xs tracking-widest uppercase", tab === id ? "bg-cream text-ink" : "text-muted hover:text-cream"),
						children: id
					}, id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[46vh] space-y-5 overflow-y-auto px-5 py-5 lg:max-h-none",
					children: [
						tab === "type" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TypeControls, {}) : null,
						tab === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageControls, {}) : null,
						tab === "verse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseControls, {}) : null
					]
				})]
			}),
			exportOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportSheet, {
				busy: exportBusy,
				onClose: () => setExportOpen(false),
				onExport: async (kind) => {
					useStudio.getState().setExportBusy(true);
					try {
						if (kind === "png") await exportPng(design, imageSrc);
						if (kind === "jpg") await exportJpg(design, imageSrc);
						if (kind === "pdf") await exportPdf(design, imageSrc);
						toast.success("Saved to your downloads.");
						setExportOpen(false);
					} catch (error) {
						toast.error(error instanceof Error ? error.message : "Export failed.");
					} finally {
						useStudio.getState().setExportBusy(false);
					}
				}
			}) : null
		]
	});
}
function TypeControls() {
	const design = useStudio((s) => s.selectedDesign());
	if (!design) return null;
	const patch = useStudio.getState().patchDesign;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Font",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: CANVAS_FONTS.map((font) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({
						fontId: font.id,
						italic: font.id === "cormorant"
					}),
					className: cn("h-10 rounded-full px-3 text-xs", design.fontId === font.id ? "bg-cream text-ink" : "text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)]"),
					style: { fontFamily: `"${font.family}", serif` },
					children: font.label
				}, font.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Color",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: TEXT_COLOR_PRESETS.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": color.label,
					onClick: () => patch({ textColor: color.value }),
					className: cn("size-9 rounded-full", design.textColor.toLowerCase() === color.value ? "shadow-[0_0_0_2px_#12100c,0_0_0_4px_#b08d57]" : "shadow-[0_0_0_1px_rgba(244,239,230,0.2)]"),
					style: { background: color.value }
				}, color.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Size",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				ariaLabel: "Text size",
				min: .024,
				max: .09,
				step: .001,
				value: design.fontSize,
				onValueChange: (fontSize) => patch({ fontSize })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Alignment",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [
					"left",
					"center",
					"right"
				].map((align) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ textAlign: align }),
					className: cn("h-10 flex-1 rounded-full text-xs capitalize", design.textAlign === align ? "bg-cream text-ink" : "text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)]"),
					children: align
				}, align))
			})
		})
	] });
}
function ImageControls() {
	const design = useStudio((s) => s.selectedDesign());
	const inputRef = (0, import_react.useRef)(null);
	if (!design) return null;
	const patchImage = useStudio.getState().patchImage;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Zoom / crop",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				ariaLabel: "Image zoom",
				min: 1,
				max: 1.45,
				step: .01,
				value: design.image.zoom,
				onValueChange: (zoom) => patchImage({ zoom })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Brightness",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				ariaLabel: "Brightness",
				min: -.25,
				max: .25,
				step: .01,
				value: design.image.brightness,
				onValueChange: (brightness) => patchImage({ brightness })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Contrast",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				ariaLabel: "Contrast",
				min: -.2,
				max: .35,
				step: .01,
				value: design.image.contrast,
				onValueChange: (contrast) => patchImage({ contrast })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
			label: "Saturation",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
				ariaLabel: "Saturation",
				min: -.3,
				max: .3,
				step: .01,
				value: design.image.saturation,
				onValueChange: (saturation) => patchImage({ saturation })
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: inputRef,
			type: "file",
			accept: "image/*",
			className: "sr-only",
			onChange: (event) => {
				const file = event.target.files?.[0];
				if (!file) return;
				const url = URL.createObjectURL(file);
				useStudio.getState().setImage(url, "upload");
				event.currentTarget.value = "";
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "gold",
			className: "w-full",
			onClick: () => inputRef.current?.click(),
			children: "Change image"
		})
	] });
}
function VerseControls() {
	const design = useStudio((s) => s.selectedDesign());
	if (!design) return null;
	const patch = useStudio.getState().patchDesign;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
		label: "Verse",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: design.reference ? `${design.verseText}\n${design.reference}` : design.verseText,
			onChange: (event) => {
				const raw = event.target.value;
				const lines = raw.trim().split("\n");
				const last = lines[lines.length - 1] ?? "";
				const looksRef = /[A-Za-z].*\d+:\d+/.test(last) && last.length < 48 && lines.length > 1;
				patch({
					verseText: looksRef ? lines.slice(0, -1).join("\n").trim() : raw,
					reference: looksRef ? last.trim() : ""
				});
			},
			rows: 7,
			className: "w-full resize-none rounded-md bg-bg px-3 py-3 text-sm leading-relaxed text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
		})
	});
}
function Control({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 font-classical text-xs tracking-widest text-gold",
		children: label.toUpperCase()
	}), children] });
}
function ExportSheet({ busy, onClose, onExport }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/70 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm rounded-xl bg-bg-elevated p-5 shadow-[0_0_0_1px_rgba(176,141,87,0.35)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-classical text-xs tracking-widest text-gold",
					children: "PRINT-READY EXPORT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-2xl text-cream",
					children: "Save canvas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "High-resolution file with no watermark, sized for physical printing."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy,
							onClick: () => void onExport("png"),
							children: "High-resolution PNG"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy,
							variant: "gold",
							onClick: () => void onExport("jpg"),
							children: "High-resolution JPG"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy,
							variant: "gold",
							onClick: () => void onExport("pdf"),
							children: "Print-ready PDF"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy,
							variant: "ghost",
							onClick: onClose,
							children: "Cancel"
						})
					]
				})
			]
		})
	});
}
function GalleryScreen() {
	const variations = useStudio((s) => s.variations);
	const selectedId = useStudio((s) => s.selectedId);
	const imageSrc = useStudio((s) => s.imageSrc);
	const selectVariation = useStudio((s) => s.selectVariation);
	const resetToCompose = useStudio((s) => s.resetToCompose);
	if (!imageSrc) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-5xl flex-col px-5 pb-24 pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: resetToCompose,
					className: "flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated",
					"aria-label": "Back",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-classical text-[0.62rem] tracking-[0.28em] text-gold",
					children: "YOUR AI DESIGNS"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-cream",
					children: "Three variations"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 md:grid-cols-3",
				children: variations.map((design, index) => {
					const meta = VARIATION_META[design.variation];
					const selected = design.id === selectedId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => selectVariation(design.id),
						className: cn("group flex flex-col text-left", `reveal-${index + 1}`),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("overflow-hidden rounded-xl bg-bg-elevated p-2 transition-shadow duration-[var(--motion-fast)]", selected ? "shadow-[0_0_0_1px_rgba(176,141,87,0.85)]" : "shadow-[0_0_0_1px_rgba(244,239,230,0.1)] group-hover:shadow-[0_0_0_1px_rgba(176,141,87,0.45)]"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesignCanvas, {
									design,
									imageSrc,
									className: "rounded-lg"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-display text-xl text-cream",
								children: meta.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: meta.subtitle
							})
						]
					}, design.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "flex-1 tracking-[0.14em]",
					disabled: !selectedId,
					onClick: () => selectedId && selectVariation(selectedId),
					children: "Edit this design"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "gold",
					className: "flex-1 tracking-[0.14em]",
					onClick: resetToCompose,
					children: "Start over"
				})]
			})
		]
	});
}
var generateOriginalImage = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("ce0622dc9c7af0d1fd9c989df4013448ca588fdd7fa263f8f3daeca30b56c2a2"));
var PRESETS = [
	{
		label: "Olive grove",
		prompt: "A sunlit olive grove on a Mediterranean hillside at golden hour, ancient trees, dusty path, cinematic natural light"
	},
	{
		label: "Dawn water",
		prompt: "A still mountain lake at dawn with soft rays of light through clouds onto calm water, mist on the far shore"
	},
	{
		label: "Chapel light",
		prompt: "Interior of a simple stone chapel with a single shaft of warm afternoon light across empty wooden pews, dust motes in the air"
	},
	{
		label: "Wheat field",
		prompt: "A quiet wheat field at sunset, warm wind in the grain, golden light, deep sky, peaceful sacred landscape"
	},
	{
		label: "Mountain path",
		prompt: "A narrow mountain path at sunrise, warm stone, distant peaks in haze, cinematic natural photography"
	},
	{
		label: "Sacred light",
		prompt: "Abstract sacred light through high clouds, volumetric rays, quiet heavens, original atmospheric photograph, no figures"
	}
];
function GenerateDialog() {
	const open = useStudio((s) => s.generateOpen);
	const setGenerateOpen = useStudio((s) => s.setGenerateOpen);
	const setImage = useStudio((s) => s.setImage);
	const [prompt, setPrompt] = (0, import_react.useState)(PRESETS[0].prompt);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!open) return null;
	async function generate() {
		setBusy(true);
		try {
			const result = await generateOriginalImage({ data: { prompt } });
			if (!result.ok) {
				toast.error(result.error);
				return;
			}
			setImage(result.dataUrl, "generated");
			setGenerateOpen(false);
			toast.success("Original scene ready. Add a verse and tap Auto Design.");
		} catch {
			toast.error("Could not generate an image right now.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/70 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-xl bg-bg-elevated p-5 shadow-[0_0_0_1px_rgba(176,141,87,0.35)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-classical text-[0.62rem] tracking-[0.28em] text-gold",
						children: "ORIGINAL IMAGE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-2xl text-cream",
						children: "Generate a scene"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setGenerateOpen(false),
						className: "flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-subtle",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: "Create an original Christian background instead of using third-party artwork. This does not copy a famous painting or commercial design."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPrompt(preset.prompt),
						className: "h-9 rounded-full px-3 text-xs text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)] hover:text-cream",
						children: preset.label
					}, preset.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: prompt,
					onChange: (event) => setPrompt(event.target.value),
					rows: 4,
					className: "mt-4 w-full resize-none rounded-md bg-bg px-3 py-3 text-sm leading-relaxed text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4 w-full tracking-[0.14em]",
					disabled: busy,
					onClick: () => void generate(),
					children: busy ? "Generating…" : "Generate original image"
				})
			]
		})
	});
}
function StudioApp() {
	const step = useStudio((s) => s.step);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-[100dvh] bg-bg text-fg",
		children: [
			step === "compose" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComposeScreen, {}) : null,
			step === "designing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesigningScreen, {}) : null,
			step === "gallery" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalleryScreen, {}) : null,
			step === "editor" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorScreen, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenerateDialog, {})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
}
//#endregion
export { Home as component };
