//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHdEul1K.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-9r8LynVJ.js", "/assets/rolldown-runtime-hePW80VL.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-9r8LynVJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B9DctaEK.js"]
	}
} });
//#endregion
export { tsrStartManifest };
