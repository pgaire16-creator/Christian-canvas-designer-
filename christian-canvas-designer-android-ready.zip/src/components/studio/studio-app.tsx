import { ComposeScreen } from "@/components/studio/compose-screen";
import { DesigningScreen } from "@/components/studio/designing-screen";
import { EditorScreen } from "@/components/studio/editor-screen";
import { GalleryScreen } from "@/components/studio/gallery-screen";
import { GenerateDialog } from "@/components/studio/generate-dialog";
import { useStudio } from "@/lib/store";

export function StudioApp() {
  const step = useStudio((s) => s.step);

  return (
    <div className="min-h-[100dvh] bg-bg text-fg">
      {step === "compose" ? <ComposeScreen /> : null}
      {step === "designing" ? <DesigningScreen /> : null}
      {step === "gallery" ? <GalleryScreen /> : null}
      {step === "editor" ? <EditorScreen /> : null}
      <GenerateDialog />
    </div>
  );
}
