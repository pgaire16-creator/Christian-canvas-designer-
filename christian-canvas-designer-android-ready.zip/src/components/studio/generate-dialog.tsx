import { X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generateOriginalImage } from "@/lib/ai/generate-image";
import { useStudio } from "@/lib/store";

const PRESETS = [
  {
    label: "Olive grove",
    prompt:
      "A sunlit olive grove on a Mediterranean hillside at golden hour, ancient trees, dusty path, cinematic natural light",
  },
  {
    label: "Dawn water",
    prompt:
      "A still mountain lake at dawn with soft rays of light through clouds onto calm water, mist on the far shore",
  },
  {
    label: "Chapel light",
    prompt:
      "Interior of a simple stone chapel with a single shaft of warm afternoon light across empty wooden pews, dust motes in the air",
  },
  {
    label: "Wheat field",
    prompt:
      "A quiet wheat field at sunset, warm wind in the grain, golden light, deep sky, peaceful sacred landscape",
  },
  {
    label: "Mountain path",
    prompt:
      "A narrow mountain path at sunrise, warm stone, distant peaks in haze, cinematic natural photography",
  },
  {
    label: "Sacred light",
    prompt:
      "Abstract sacred light through high clouds, volumetric rays, quiet heavens, original atmospheric photograph, no figures",
  },
];

export function GenerateDialog() {
  const open = useStudio((s) => s.generateOpen);
  const setGenerateOpen = useStudio((s) => s.setGenerateOpen);
  const setImage = useStudio((s) => s.setImage);
  const [prompt, setPrompt] = useState(PRESETS[0]!.prompt);
  const [busy, setBusy] = useState(false);

  if (!open) return null;

  async function generate() {
    setBusy(true);
    try {
      const result = await generateOriginalImage({ data: { prompt } });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      setImage(result.dataUrl, "generated");
      setGenerateOpen(false);
      toast.success("Original scene ready. Add a verse and tap Auto Design.");
    } catch {
      toast.error("Could not generate an image right now.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/70 p-4 sm:items-center">
      <div className="max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-xl bg-bg-elevated p-5 shadow-[0_0_0_1px_rgba(176,141,87,0.35)]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-classical text-[0.62rem] tracking-[0.28em] text-gold">
              ORIGINAL IMAGE
            </p>
            <h2 className="mt-2 font-display text-2xl text-cream">
              Generate a scene
            </h2>
          </div>
          <button
            type="button"
            onClick={() => setGenerateOpen(false)}
            className="flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-subtle"
            aria-label="Close"
          >
            <X className="size-4" />
          </button>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Create an original Christian background instead of using third-party
          artwork. This does not copy a famous painting or commercial design.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {PRESETS.map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => setPrompt(preset.prompt)}
              className="h-9 rounded-full px-3 text-xs text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)] hover:text-cream"
            >
              {preset.label}
            </button>
          ))}
        </div>
        <textarea
          value={prompt}
          onChange={(event) => setPrompt(event.target.value)}
          rows={4}
          className="mt-4 w-full resize-none rounded-md bg-bg px-3 py-3 text-sm leading-relaxed text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
        />
        <Button
          className="mt-4 w-full tracking-[0.14em]"
          disabled={busy}
          onClick={() => void generate()}
        >
          {busy ? "Generating…" : "Generate original image"}
        </Button>
      </div>
    </div>
  );
}
