import {
  ArrowLeft,
  Download,
  Redo2,
  Undo2,
} from "lucide-react";
import { useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { DesignCanvas } from "@/components/studio/design-canvas";
import { CANVAS_FONTS } from "@/lib/fonts";
import { exportJpg, exportPdf, exportPng } from "@/lib/export-design";
import { useStudio } from "@/lib/store";
import { TEXT_COLOR_PRESETS, VARIATION_META } from "@/lib/types";
import { cn } from "@/lib/utils";

type EditTab = "type" | "image" | "verse";

export function EditorScreen() {
  const imageSrc = useStudio((s) => s.imageSrc);
  const variations = useStudio((s) => s.variations);
  const selectedId = useStudio((s) => s.selectedId);
  const design = variations.find((v) => v.id === selectedId) ?? null;
  const history = useStudio((s) => s.history);
  const future = useStudio((s) => s.future);
  const editMode = useStudio((s) => s.editMode);
  const exportBusy = useStudio((s) => s.exportBusy);
  const [tab, setTab] = useState<EditTab>("type");
  const [exportOpen, setExportOpen] = useState(false);

  if (!design || !imageSrc) return null;

  return (
    <div className="mx-auto flex min-h-[100dvh] w-full max-w-6xl flex-col lg:flex-row">
      <div className="flex min-h-0 flex-1 flex-col">
        <header className="flex items-center gap-1 px-3 py-3">
          <button
            type="button"
            onClick={() => useStudio.setState({ step: "gallery" })}
            className="flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated"
            aria-label="Back to designs"
          >
            <ArrowLeft className="size-5" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-lg text-cream">
              {VARIATION_META[design.variation].title}
            </p>
            <p className="text-xs text-muted">
              Drag to move {editMode === "text" ? "the verse" : "the crop"}
            </p>
          </div>
          <button
            type="button"
            onClick={() => useStudio.getState().undo()}
            disabled={history.length === 0}
            className="flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated disabled:opacity-30"
            aria-label="Undo"
          >
            <Undo2 className="size-4" />
          </button>
          <button
            type="button"
            onClick={() => useStudio.getState().redo()}
            disabled={future.length === 0}
            className="flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated disabled:opacity-30"
            aria-label="Redo"
          >
            <Redo2 className="size-4" />
          </button>
          <Button
            size="sm"
            className="ml-1"
            onClick={() => setExportOpen(true)}
          >
            <Download className="size-4" />
            Export
          </Button>
        </header>

        <div className="flex flex-1 items-center justify-center px-4 pb-4">
          <div className="w-full max-w-md rounded-xl bg-bg-elevated p-2 shadow-[0_0_0_1px_rgba(176,141,87,0.35)] lg:max-w-lg">
            <DesignCanvas
              design={design}
              imageSrc={imageSrc}
              guides
              interactive
              mode={editMode}
              className="rounded-lg"
              onDragStart={() => useStudio.getState().commit()}
              onTextDrag={(x, y) => {
                useStudio.getState().setEditMode("text");
                useStudio.getState().patchDesign({ textX: x, textY: y }, false);
              }}
              onImageDrag={(x, y) => {
                useStudio.getState().patchImage({ cropX: x, cropY: y }, false);
              }}
            />
          </div>
        </div>
      </div>

      <aside className="border-t border-border bg-bg-elevated lg:w-90 lg:border-l lg:border-t-0">
        <div className="flex gap-1 px-4 pt-4">
          {(["type", "image", "verse"] as const).map((id) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                setTab(id);
                if (id === "image") useStudio.getState().setEditMode("image");
                if (id === "type") useStudio.getState().setEditMode("text");
              }}
              className={cn(
                "h-10 flex-1 rounded-full text-xs tracking-widest uppercase",
                tab === id ? "bg-cream text-ink" : "text-muted hover:text-cream",
              )}
            >
              {id}
            </button>
          ))}
        </div>

        <div className="max-h-[46vh] space-y-5 overflow-y-auto px-5 py-5 lg:max-h-none">
          {tab === "type" ? <TypeControls /> : null}
          {tab === "image" ? <ImageControls /> : null}
          {tab === "verse" ? <VerseControls /> : null}
        </div>
      </aside>

      {exportOpen ? (
        <ExportSheet
          busy={exportBusy}
          onClose={() => setExportOpen(false)}
          onExport={async (kind) => {
            useStudio.getState().setExportBusy(true);
            try {
              if (kind === "png") await exportPng(design, imageSrc);
              if (kind === "jpg") await exportJpg(design, imageSrc);
              if (kind === "pdf") await exportPdf(design, imageSrc);
              toast.success("Saved to your downloads.");
              setExportOpen(false);
            } catch (error) {
              toast.error(
                error instanceof Error ? error.message : "Export failed.",
              );
            } finally {
              useStudio.getState().setExportBusy(false);
            }
          }}
        />
      ) : null}
    </div>
  );
}

function TypeControls() {
  const design = useStudio((s) => s.selectedDesign());
  if (!design) return null;
  const patch = useStudio.getState().patchDesign;

  return (
    <>
      <Control label="Font">
        <div className="flex flex-wrap gap-2">
          {CANVAS_FONTS.map((font) => (
            <button
              key={font.id}
              type="button"
              onClick={() =>
                patch({ fontId: font.id, italic: font.id === "cormorant" })
              }
              className={cn(
                "h-10 rounded-full px-3 text-xs",
                design.fontId === font.id
                  ? "bg-cream text-ink"
                  : "text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)]",
              )}
              style={{ fontFamily: `"${font.family}", serif` }}
            >
              {font.label}
            </button>
          ))}
        </div>
      </Control>
      <Control label="Color">
        <div className="flex gap-2">
          {TEXT_COLOR_PRESETS.map((color) => (
            <button
              key={color.id}
              type="button"
              aria-label={color.label}
              onClick={() => patch({ textColor: color.value })}
              className={cn(
                "size-9 rounded-full",
                design.textColor.toLowerCase() === color.value
                  ? "shadow-[0_0_0_2px_#12100c,0_0_0_4px_#b08d57]"
                  : "shadow-[0_0_0_1px_rgba(244,239,230,0.2)]",
              )}
              style={{ background: color.value }}
            />
          ))}
        </div>
      </Control>
      <Control label="Size">
        <Slider
          ariaLabel="Text size"
          min={0.024}
          max={0.09}
          step={0.001}
          value={design.fontSize}
          onValueChange={(fontSize) => patch({ fontSize })}
        />
      </Control>
      <Control label="Alignment">
        <div className="flex gap-2">
          {(["left", "center", "right"] as const).map((align) => (
            <button
              key={align}
              type="button"
              onClick={() => patch({ textAlign: align })}
              className={cn(
                "h-10 flex-1 rounded-full text-xs capitalize",
                design.textAlign === align
                  ? "bg-cream text-ink"
                  : "text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)]",
              )}
            >
              {align}
            </button>
          ))}
        </div>
      </Control>
    </>
  );
}

function ImageControls() {
  const design = useStudio((s) => s.selectedDesign());
  const inputRef = useRef<HTMLInputElement>(null);
  if (!design) return null;
  const patchImage = useStudio.getState().patchImage;

  return (
    <>
      <Control label="Zoom / crop">
        <Slider
          ariaLabel="Image zoom"
          min={1}
          max={1.45}
          step={0.01}
          value={design.image.zoom}
          onValueChange={(zoom) => patchImage({ zoom })}
        />
      </Control>
      <Control label="Brightness">
        <Slider
          ariaLabel="Brightness"
          min={-0.25}
          max={0.25}
          step={0.01}
          value={design.image.brightness}
          onValueChange={(brightness) => patchImage({ brightness })}
        />
      </Control>
      <Control label="Contrast">
        <Slider
          ariaLabel="Contrast"
          min={-0.2}
          max={0.35}
          step={0.01}
          value={design.image.contrast}
          onValueChange={(contrast) => patchImage({ contrast })}
        />
      </Control>
      <Control label="Saturation">
        <Slider
          ariaLabel="Saturation"
          min={-0.3}
          max={0.3}
          step={0.01}
          value={design.image.saturation}
          onValueChange={(saturation) => patchImage({ saturation })}
        />
      </Control>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        hidden
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (!file) return;
          const url = URL.createObjectURL(file);
          useStudio.getState().setImage(url, "upload");
          event.currentTarget.value = "";
        }}
      />
      <Button variant="gold" className="w-full" onClick={() => inputRef.current?.click()}>
        Change image
      </Button>
    </>
  );
}

function VerseControls() {
  const design = useStudio((s) => s.selectedDesign());
  if (!design) return null;
  const patch = useStudio.getState().patchDesign;

  return (
    <Control label="Verse">
      <textarea
        value={
          design.reference
            ? `${design.verseText}\n${design.reference}`
            : design.verseText
        }
        onChange={(event) => {
          const raw = event.target.value;
          const lines = raw.trim().split("\n");
          const last = lines[lines.length - 1] ?? "";
          const looksRef =
            /[A-Za-z].*\d+:\d+/.test(last) && last.length < 48 && lines.length > 1;
          patch({
            verseText: looksRef ? lines.slice(0, -1).join("\n").trim() : raw,
            reference: looksRef ? last.trim() : "",
          });
        }}
        rows={7}
        className="w-full resize-none rounded-md bg-bg px-3 py-3 text-sm leading-relaxed text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
      />
    </Control>
  );
}

function Control({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div>
      <p className="mb-2 font-classical text-xs tracking-widest text-gold">
        {label.toUpperCase()}
      </p>
      {children}
    </div>
  );
}

function ExportSheet({
  busy,
  onClose,
  onExport,
}: {
  busy: boolean;
  onClose: () => void;
  onExport: (kind: "png" | "jpg" | "pdf") => Promise<void>;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/70 p-4 sm:items-center">
      <div className="w-full max-w-sm rounded-xl bg-bg-elevated p-5 shadow-[0_0_0_1px_rgba(176,141,87,0.35)]">
        <p className="font-classical text-xs tracking-widest text-gold">
          PRINT-READY EXPORT
        </p>
        <h2 className="mt-2 font-display text-2xl text-cream">Save canvas</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          High-resolution file with no watermark, sized for physical printing.
        </p>
        <div className="mt-5 flex flex-col gap-2">
          <Button disabled={busy} onClick={() => void onExport("png")}>
            High-resolution PNG
          </Button>
          <Button disabled={busy} variant="gold" onClick={() => void onExport("jpg")}>
            High-resolution JPG
          </Button>
          <Button disabled={busy} variant="gold" onClick={() => void onExport("pdf")}>
            Print-ready PDF
          </Button>
          <Button disabled={busy} variant="ghost" onClick={onClose}>
            Cancel
          </Button>
        </div>
      </div>
    </div>
  );
}
