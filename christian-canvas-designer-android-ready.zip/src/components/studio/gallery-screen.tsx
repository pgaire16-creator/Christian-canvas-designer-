import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DesignCanvas } from "@/components/studio/design-canvas";
import { useStudio } from "@/lib/store";
import { VARIATION_META } from "@/lib/types";
import { cn } from "@/lib/utils";

export function GalleryScreen() {
  const variations = useStudio((s) => s.variations);
  const selectedId = useStudio((s) => s.selectedId);
  const imageSrc = useStudio((s) => s.imageSrc);
  const selectVariation = useStudio((s) => s.selectVariation);
  const resetToCompose = useStudio((s) => s.resetToCompose);

  if (!imageSrc) return null;

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col px-5 pb-24 pt-6">
      <div className="mb-6 flex items-center gap-3">
        <button
          type="button"
          onClick={resetToCompose}
          className="flex size-11 items-center justify-center rounded-md text-cream hover:bg-bg-elevated"
          aria-label="Back"
        >
          <ArrowLeft className="size-5" />
        </button>
        <div>
          <p className="font-classical text-[0.62rem] tracking-[0.28em] text-gold">
            YOUR AI DESIGNS
          </p>
          <h1 className="font-display text-3xl text-cream">Three variations</h1>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {variations.map((design, index) => {
          const meta = VARIATION_META[design.variation];
          const selected = design.id === selectedId;
          return (
            <button
              key={design.id}
              type="button"
              onClick={() => selectVariation(design.id)}
              className={cn(
                "group flex flex-col text-left",
                `reveal-${index + 1}`,
              )}
            >
              <div
                className={cn(
                  "overflow-hidden rounded-xl bg-bg-elevated p-2 transition-shadow duration-[var(--motion-fast)]",
                  selected
                    ? "shadow-[0_0_0_1px_rgba(176,141,87,0.85)]"
                    : "shadow-[0_0_0_1px_rgba(244,239,230,0.1)] group-hover:shadow-[0_0_0_1px_rgba(176,141,87,0.45)]",
                )}
              >
                <DesignCanvas
                  design={design}
                  imageSrc={imageSrc}
                  className="rounded-lg"
                />
              </div>
              <p className="mt-3 font-display text-xl text-cream">{meta.title}</p>
              <p className="text-sm text-muted">{meta.subtitle}</p>
            </button>
          );
        })}
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Button
          size="lg"
          className="flex-1 tracking-[0.14em]"
          disabled={!selectedId}
          onClick={() => selectedId && selectVariation(selectedId)}
        >
          Edit this design
        </Button>
        <Button
          size="lg"
          variant="gold"
          className="flex-1 tracking-[0.14em]"
          onClick={resetToCompose}
        >
          Start over
        </Button>
      </div>
    </div>
  );
}
