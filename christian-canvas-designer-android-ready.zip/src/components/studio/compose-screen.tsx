import { ImagePlus, Sparkles, Upload } from "lucide-react";
import { useRef } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CrossMark } from "@/components/studio/mark";
import { CANVAS_SIZES } from "@/lib/canvas-sizes";
import { runAutoDesign } from "@/lib/run-auto-design";
import { useStudio } from "@/lib/store";
import { SAMPLE_SCENES } from "@/lib/types";
import { SAMPLE_VERSES, formatVerseInput } from "@/lib/verses";
import { cn } from "@/lib/utils";

export function ComposeScreen() {
  const inputRef = useRef<HTMLInputElement>(null);
  const imageSrc = useStudio((s) => s.imageSrc);
  const imageOrigin = useStudio((s) => s.imageOrigin);
  const verse = useStudio((s) => s.verse);
  const canvasSizeId = useStudio((s) => s.canvasSizeId);
  const customWidthIn = useStudio((s) => s.customWidthIn);
  const customHeightIn = useStudio((s) => s.customHeightIn);
  const setImage = useStudio((s) => s.setImage);
  const clearImage = useStudio((s) => s.clearImage);
  const setVerse = useStudio((s) => s.setVerse);
  const setCanvasSizeId = useStudio((s) => s.setCanvasSizeId);
  const setCustomSize = useStudio((s) => s.setCustomSize);
  const setGenerateOpen = useStudio((s) => s.setGenerateOpen);

  function onFile(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please choose a JPG, PNG, or WebP photo.");
      return;
    }
    const url = URL.createObjectURL(file);
    setImage(url, "upload");
  }

  async function onAutoDesign() {
    if (!imageSrc) {
      toast.error("Upload a photo or choose a scene first.");
      return;
    }
    if (!verse.trim()) {
      toast.error("Add a Bible verse to place on the canvas.");
      return;
    }
    try {
      await runAutoDesign();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Auto Design failed.");
      useStudio.getState().resetToCompose();
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-lg flex-col gap-6 px-5 pb-28 pt-6 sm:pt-10">
      <header className="reveal flex flex-col items-center text-center">
        <CrossMark className="mb-4 h-8 w-6 text-gold" />
        <p className="font-classical text-[0.68rem] font-medium tracking-[0.38em] text-gold">
          CHRISTIAN CANVAS
        </p>
        <h1 className="mt-2 font-display text-[2.35rem] font-medium leading-[1.1] text-cream sm:text-5xl">
          Designer AI
        </h1>
        <p className="mt-3 max-w-sm text-pretty text-sm leading-relaxed text-muted">
          Upload a photo, add a verse, and Auto Design builds a print-ready
          wall canvas for you.
        </p>
      </header>

      <section className="reveal-2">
        <FieldLabel>Upload photo</FieldLabel>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          hidden
          className="hidden"
          onChange={(event) => {
            onFile(event.target.files?.[0]);
            event.currentTarget.value = "";
          }}
        />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className={cn(
            "group relative flex w-full overflow-hidden rounded-xl bg-bg-elevated text-left shadow-[0_0_0_1px_rgba(176,141,87,0.28)] transition-shadow duration-[var(--motion-quick)] hover:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]",
            imageSrc ? "aspect-[4/5] sm:aspect-[4/3]" : "min-h-44 items-center justify-center",
          )}
        >
          {imageSrc ? (
            <>
              <img
                src={imageSrc}
                alt="Selected artwork"
                className="h-full w-full object-cover"
              />
              <span className="absolute inset-x-3 bottom-3 flex items-center justify-center gap-2 rounded-md bg-ink/80 px-3 py-2 text-xs tracking-[0.12em] text-cream">
                <Upload className="size-3.5" />
                Change photo
              </span>
            </>
          ) : (
            <span className="flex flex-col items-center gap-3 px-6 py-10 text-center">
              <span className="flex size-12 items-center justify-center rounded-md bg-bg-subtle text-gold">
                <ImagePlus className="size-5" />
              </span>
              <span className="text-sm text-cream">Tap to upload a photo</span>
              <span className="text-xs text-subtle">
                Jesus, Christian artwork, or a quiet scene
              </span>
            </span>
          )}
        </button>

        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {SAMPLE_SCENES.map((scene) => (
            <button
              key={scene.id}
              type="button"
              onClick={() => setImage(scene.src, "sample")}
              className={cn(
                "relative h-16 w-16 shrink-0 overflow-hidden rounded-md shadow-[0_0_0_1px_rgba(244,239,230,0.12)]",
                imageSrc === scene.src && "shadow-[0_0_0_1px_rgba(176,141,87,0.9)]",
              )}
            >
              <img
                src={scene.src}
                alt={scene.label}
                className="h-full w-full object-cover"
              />
            </button>
          ))}
          <button
            type="button"
            onClick={() => setGenerateOpen(true)}
            className="flex h-16 w-16 shrink-0 flex-col items-center justify-center gap-1 rounded-md bg-bg-elevated text-gold shadow-[0_0_0_1px_rgba(176,141,87,0.35)]"
          >
            <Sparkles className="size-4" />
            <span className="text-[0.6rem] tracking-[0.08em]">Original</span>
          </button>
        </div>

        {imageOrigin === "upload" ? (
          <p className="mt-3 text-xs leading-relaxed text-subtle">
            Make sure you have permission to use this image commercially.
          </p>
        ) : null}
        {imageSrc ? (
          <button
            type="button"
            onClick={clearImage}
            className="mt-2 text-xs text-muted underline-offset-4 hover:text-cream hover:underline"
          >
            Remove photo
          </button>
        ) : null}
      </section>

      <section className="reveal-3">
        <FieldLabel>Paste Bible verse</FieldLabel>
        <textarea
          value={verse}
          onChange={(event) => setVerse(event.target.value)}
          rows={4}
          placeholder="For God so loved the world… John 3:16"
          className="w-full resize-none rounded-lg bg-bg-elevated px-4 py-3 text-sm leading-relaxed text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none placeholder:text-subtle focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
        />
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {SAMPLE_VERSES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setVerse(formatVerseInput(item.text, item.reference))}
              className="h-9 shrink-0 rounded-full px-3 text-xs text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)] hover:text-cream"
            >
              {item.reference}
            </button>
          ))}
        </div>
      </section>

      <section className="reveal-4">
        <FieldLabel>Canvas size</FieldLabel>
        <div className="flex flex-wrap gap-2">
          {CANVAS_SIZES.map((size) => (
            <button
              key={size.id}
              type="button"
              onClick={() => setCanvasSizeId(size.id)}
              className={cn(
                "h-10 rounded-full px-3.5 text-xs tracking-[0.04em] transition-colors",
                canvasSizeId === size.id
                  ? "bg-cream text-ink"
                  : "text-muted shadow-[0_0_0_1px_rgba(244,239,230,0.12)] hover:text-cream",
              )}
            >
              {size.label}
            </button>
          ))}
        </div>
        {canvasSizeId === "custom" ? (
          <div className="mt-3 grid grid-cols-2 gap-3">
            <NumberField
              label="Width (in)"
              value={customWidthIn}
              onChange={(n) => setCustomSize(n, customHeightIn)}
            />
            <NumberField
              label="Height (in)"
              value={customHeightIn}
              onChange={(n) => setCustomSize(customWidthIn, n)}
            />
          </div>
        ) : null}
      </section>

      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-20 bg-[linear-gradient(to_top,var(--color-bg)_70%,transparent)] px-5 pb-5 pt-8">
        <Button
          size="lg"
          className="pointer-events-auto h-12 w-full max-w-lg mx-auto flex rounded-lg font-medium tracking-[0.18em]"
          onClick={() => void onAutoDesign()}
        >
          AUTO DESIGN
        </Button>
      </div>
    </div>
  );
}

function FieldLabel({ children }: { children: string }) {
  return (
    <p className="mb-2 font-classical text-[0.62rem] font-medium tracking-[0.28em] text-gold">
      {children.toUpperCase()}
    </p>
  );
}

function NumberField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-xs text-muted">
      {label}
      <input
        type="number"
        min={6}
        max={40}
        step={0.01}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        className="h-11 rounded-md bg-bg-elevated px-3 text-sm text-cream shadow-[0_0_0_1px_rgba(244,239,230,0.1)] outline-none focus-visible:shadow-[0_0_0_1px_rgba(176,141,87,0.55)]"
      />
    </label>
  );
}
