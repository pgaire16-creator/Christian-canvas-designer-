import { useStudio } from "@/lib/store";
import { CrossMark } from "@/components/studio/mark";

export function DesigningScreen() {
  const imageSrc = useStudio((s) => s.imageSrc);
  const status = useStudio((s) => s.designStatus);

  return (
    <div className="mx-auto flex min-h-[100dvh] w-full max-w-lg flex-col items-center justify-center px-6 py-12">
      <div className="relative w-full max-w-xs overflow-hidden rounded-xl bg-bg-elevated shadow-[0_0_0_1px_rgba(176,141,87,0.35)]">
        {imageSrc ? (
          <img
            src={imageSrc}
            alt=""
            className="aspect-[3/4] w-full object-cover opacity-70"
          />
        ) : (
          <div className="aspect-[3/4] w-full bg-bg-subtle" />
        )}
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_bottom,rgba(18,16,12,0.2),rgba(18,16,12,0.55))]" />
        <div className="scan-line" />
      </div>
      <CrossMark className="mt-8 h-7 w-5 text-gold" />
      <p className="mt-4 font-classical text-[0.68rem] tracking-[0.32em] text-gold">
        AUTO DESIGN
      </p>
      <p className="mt-3 text-center font-display text-2xl text-cream">
        {status || "Composing your canvas"}
      </p>
      <p className="mt-2 max-w-xs text-center text-sm leading-relaxed text-muted">
        Choosing crop, type, color, and print-safe margins from your photo.
      </p>
    </div>
  );
}
