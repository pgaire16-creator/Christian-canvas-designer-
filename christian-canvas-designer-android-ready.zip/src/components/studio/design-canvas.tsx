import { useEffect, useRef, type PointerEvent } from "react";
import { renderDesign } from "@/lib/canvas-render";
import { getCanvasSize } from "@/lib/canvas-sizes";
import type { DesignState } from "@/lib/types";
import { cn } from "@/lib/utils";

interface DesignCanvasProps {
  design: DesignState;
  imageSrc: string;
  className?: string;
  guides?: boolean;
  interactive?: boolean;
  mode?: "text" | "image";
  onDragStart?: () => void;
  onTextDrag?: (x: number, y: number) => void;
  onImageDrag?: (x: number, y: number) => void;
}

export function DesignCanvas({
  design,
  imageSrc,
  className,
  guides = false,
  interactive = false,
  mode = "text",
  onDragStart,
  onTextDrag,
  onImageDrag,
}: DesignCanvasProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dragRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const size = getCanvasSize(
    design.canvasSizeId,
    design.customWidthIn,
    design.customHeightIn,
  );

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    let cancelled = false;

    const draw = async () => {
      const rect = wrap.getBoundingClientRect();
      if (rect.width < 4 || rect.height < 4) return;
      const dpr = Math.min(2.5, window.devicePixelRatio || 1);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
      try {
        await renderDesign(canvas, design, imageSrc, { guides });
      } catch {
        if (!cancelled) {
          const ctx = canvas.getContext("2d");
          if (ctx) {
            ctx.fillStyle = "#1c1812";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
          }
        }
      }
    };

    const observer = new ResizeObserver(() => {
      void draw();
    });
    observer.observe(wrap);
    void draw();
    return () => {
      cancelled = true;
      observer.disconnect();
    };
  }, [design, imageSrc, guides]);

  function clientToNorm(event: PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) / rect.width,
      y: (event.clientY - rect.top) / rect.height,
    };
  }

  return (
    <div
      ref={wrapRef}
      className={cn("relative overflow-hidden bg-ink", className)}
      style={{ aspectRatio: `${size.widthIn} / ${size.heightIn}` }}
    >
      <canvas
        ref={canvasRef}
        className={cn(
          "block h-full w-full touch-none",
          interactive && (mode === "text" ? "cursor-move" : "cursor-grab active:cursor-grabbing"),
        )}
        onPointerDown={(event) => {
          if (!interactive) return;
          const pos = clientToNorm(event);
          dragRef.current = {
            pointerId: event.pointerId,
            startX: pos.x,
            startY: pos.y,
            origX: mode === "text" ? design.textX : design.image.cropX,
            origY: mode === "text" ? design.textY : design.image.cropY,
          };
          onDragStart?.();
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={(event) => {
          const drag = dragRef.current;
          if (!drag || event.pointerId !== drag.pointerId) return;
          const pos = clientToNorm(event);
          const dx = pos.x - drag.startX;
          const dy = pos.y - drag.startY;
          if (mode === "text") {
            onTextDrag?.(
              clamp01(drag.origX + dx, 0.16, 0.84),
              clamp01(drag.origY + dy, 0.14, 0.9),
            );
          } else {
            onImageDrag?.(
              clamp01(drag.origX - dx * 0.55, 0.2, 0.8),
              clamp01(drag.origY - dy * 0.55, 0.2, 0.8),
            );
          }
        }}
        onPointerUp={(event) => {
          if (!dragRef.current) return;
          dragRef.current = null;
          event.currentTarget.releasePointerCapture(event.pointerId);
        }}
        onPointerCancel={() => {
          dragRef.current = null;
        }}
      />
    </div>
  );
}

function clamp01(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}
