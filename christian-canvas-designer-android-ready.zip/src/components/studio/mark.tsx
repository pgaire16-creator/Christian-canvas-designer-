export function CrossMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 32"
      className={className}
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.25"
    >
      <path d="M12 2v28M5 11h14" strokeLinecap="round" />
    </svg>
  );
}
