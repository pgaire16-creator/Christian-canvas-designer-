import * as SliderPrimitive from "@radix-ui/react-slider";
import { cn } from "@/lib/utils";

export function Slider({
  value,
  min = 0,
  max = 1,
  step = 0.01,
  onValueChange,
  className,
  ariaLabel,
}: {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onValueChange: (value: number) => void;
  className?: string;
  ariaLabel: string;
}) {
  return (
    <SliderPrimitive.Root
      className={cn(
        "relative flex h-11 w-full touch-none select-none items-center",
        className,
      )}
      value={[value]}
      min={min}
      max={max}
      step={step}
      onValueChange={(v) => onValueChange(v[0] ?? min)}
      aria-label={ariaLabel}
    >
      <SliderPrimitive.Track className="relative h-1 w-full grow rounded-full bg-bg-subtle">
        <SliderPrimitive.Range className="absolute h-full rounded-full bg-gold" />
      </SliderPrimitive.Track>
      <SliderPrimitive.Thumb className="block size-4 rounded-full bg-cream shadow-[0_0_0_1px_rgba(28,24,18,0.35)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60" />
    </SliderPrimitive.Root>
  );
}
