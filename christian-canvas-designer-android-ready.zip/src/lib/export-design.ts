import { exportBasename, exportDpi, getCanvasSize } from "@/lib/canvas-sizes";
import { getPrintPixels, loadImage, paintDesign } from "@/lib/canvas-render";
import { ensureCanvasFonts } from "@/lib/fonts";
import type { DesignState } from "@/lib/types";
import { downloadBlob } from "@/lib/utils";
import { jsPDF } from "jspdf";

async function renderExportCanvas(design: DesignState, imageSrc: string) {
  await ensureCanvasFonts();
  const size = getCanvasSize(
    design.canvasSizeId,
    design.customWidthIn,
    design.customHeightIn,
  );
  const dpi = exportDpi(size.widthIn, size.heightIn);
  const { width, height } = getPrintPixels(design, dpi);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not create an export canvas.");
  const img = await loadImage(imageSrc);
  paintDesign(ctx, width, height, design, img, false);
  return { canvas, size };
}

function toBlob(
  canvas: HTMLCanvasElement,
  type: string,
  quality?: number,
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) reject(new Error("Could not export the canvas."));
        else resolve(blob);
      },
      type,
      quality,
    );
  });
}

export async function exportPng(design: DesignState, imageSrc: string) {
  const { canvas, size } = await renderExportCanvas(design, imageSrc);
  const blob = await toBlob(canvas, "image/png");
  downloadBlob(blob, `${exportBasename(size)}.png`);
}

export async function exportJpg(design: DesignState, imageSrc: string) {
  const { canvas, size } = await renderExportCanvas(design, imageSrc);
  const blob = await toBlob(canvas, "image/jpeg", 0.95);
  downloadBlob(blob, `${exportBasename(size)}.jpg`);
}

export async function exportPdf(design: DesignState, imageSrc: string) {
  const { canvas, size } = await renderExportCanvas(design, imageSrc);
  const dataUrl = canvas.toDataURL("image/jpeg", 0.93);
  const orientation = size.widthIn > size.heightIn ? "landscape" : "portrait";
  const pdf = new jsPDF({
    orientation,
    unit: "in",
    format: [size.widthIn, size.heightIn],
    compress: true,
  });
  pdf.addImage(dataUrl, "JPEG", 0, 0, size.widthIn, size.heightIn);
  pdf.save(`${exportBasename(size)}.pdf`);
}
