export interface CanvasSize {
  id: string;
  label: string;
  widthIn: number;
  heightIn: number;
  auto?: boolean;
  custom?: boolean;
}

export const CANVAS_SIZES: CanvasSize[] = [
  { id: "auto", label: "Auto", widthIn: 16, heightIn: 20, auto: true },
  { id: "12x16", label: "12 × 16 in", widthIn: 12, heightIn: 16 },
  { id: "16x20", label: "16 × 20 in", widthIn: 16, heightIn: 20 },
  { id: "18x24", label: "18 × 24 in", widthIn: 18, heightIn: 24 },
  { id: "a4", label: "A4", widthIn: 8.27, heightIn: 11.69 },
  { id: "a3", label: "A3", widthIn: 11.69, heightIn: 16.54 },
  { id: "18x25", label: "18 × 25 in", widthIn: 18, heightIn: 25 },
  { id: "custom", label: "Custom", widthIn: 16, heightIn: 20, custom: true },
];

export function getCanvasSize(
  id: string,
  customWidth = 16,
  customHeight = 20,
): CanvasSize {
  const found = CANVAS_SIZES.find((s) => s.id === id) ?? CANVAS_SIZES[1]!;
  if (found.custom) {
    return {
      ...found,
      widthIn: clampSize(customWidth),
      heightIn: clampSize(customHeight),
      label: `${formatIn(customWidth)} × ${formatIn(customHeight)} in`,
    };
  }
  return found;
}

export function clampSize(n: number) {
  if (!Number.isFinite(n)) return 16;
  return Math.min(40, Math.max(6, n));
}

export function formatIn(n: number) {
  const rounded = Math.round(n * 100) / 100;
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2);
}

export function pickAutoSize(imageAspect: number): CanvasSize {
  const presets = CANVAS_SIZES.filter((s) => !s.auto && !s.custom);
  let best = presets[1] ?? presets[0]!;
  let bestDelta = Infinity;
  for (const size of presets) {
    const delta = Math.abs(size.widthIn / size.heightIn - imageAspect);
    if (delta < bestDelta) {
      best = size;
      bestDelta = delta;
    }
  }
  return best;
}

export function exportDpi(widthIn: number, heightIn: number) {
  const area = widthIn * heightIn;
  if (area >= 420) return 140;
  if (area >= 300) return 160;
  return 180;
}

function formatFileSizeLabel(size: CanvasSize) {
  return size.id === "custom" ? size.label.replace(/\s/g, "") : size.id;
}

export function exportBasename(size: CanvasSize) {
  return `christian-canvas-${formatFileSizeLabel(size)}`;
}
