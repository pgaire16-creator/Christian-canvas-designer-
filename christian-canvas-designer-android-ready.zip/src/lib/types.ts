export type AppStep = "compose" | "designing" | "gallery" | "editor";

export type ImageOrigin = "upload" | "sample" | "generated";

export type VariationKind = "classic" | "modern" | "cinematic";

export type TextAnchor = "top" | "bottom" | "left" | "right";

export type OverlayKind =
  | "none"
  | "bottom-gradient"
  | "top-gradient"
  | "left-gradient"
  | "right-gradient"
  | "soft-panel";

export interface ImageAdjustments {
  cropX: number;
  cropY: number;
  zoom: number;
  brightness: number;
  contrast: number;
  saturation: number;
  temperature: number;
  vignette: number;
}

export interface OverlaySpec {
  kind: OverlayKind;
  color: string;
  opacity: number;
}

export interface TextShadowSpec {
  blur: number;
  opacity: number;
  y: number;
}

export interface DesignState {
  id: string;
  variation: VariationKind;
  title: string;
  verseText: string;
  reference: string;
  fontId: string;
  fontWeight: number;
  italic: boolean;
  fontSize: number;
  letterSpacing: number;
  lineHeight: number;
  textAlign: CanvasTextAlign;
  textColor: string;
  textOpacity: number;
  textX: number;
  textY: number;
  textWidth: number;
  textShadow: TextShadowSpec;
  textOutline: { width: number; color: string } | null;
  overlay: OverlaySpec;
  image: ImageAdjustments;
  canvasSizeId: string;
  customWidthIn: number;
  customHeightIn: number;
}

export interface GridCell {
  luma: number;
  variance: number;
  edge: number;
  sat: number;
}

export interface ImageAnalysis {
  width: number;
  height: number;
  aspect: number;
  meanLuma: number;
  contrast: number;
  saturation: number;
  grid: GridCell[];
  subject: { col: number; row: number; x: number; y: number };
  textAnchor: TextAnchor;
  textColor: string;
  overlayColor: string;
  needsOverlay: boolean;
  overlayOpacity: number;
  recommendedSizeId: string;
  faceRegion: { x: number; y: number; w: number; h: number } | null;
  enhancement: {
    brightness: number;
    contrast: number;
    saturation: number;
    temperature: number;
    vignette: number;
  };
}

export const SAMPLE_SCENES = [
  {
    id: "olive-grove",
    src: "/samples/olive-grove.jpg",
    label: "Olive grove",
  },
  {
    id: "dawn-lake",
    src: "/samples/dawn-lake.jpg",
    label: "Dawn lake",
  },
  {
    id: "chapel-light",
    src: "/samples/chapel-light.jpg",
    label: "Chapel light",
  },
] as const;

export const TEXT_COLOR_PRESETS = [
  { id: "cream", value: "#f4efe6", label: "Cream" },
  { id: "white", value: "#fbfaf7", label: "White" },
  { id: "gold", value: "#d4bc8a", label: "Gold" },
  { id: "ink", value: "#1c1812", label: "Ink" },
  { id: "charcoal", value: "#2b261f", label: "Charcoal" },
] as const;

export const VARIATION_META: Record<
  VariationKind,
  { title: string; subtitle: string }
> = {
  classic: {
    title: "Classic Christian",
    subtitle: "Elegant serif, balanced and timeless",
  },
  modern: {
    title: "Modern Premium",
    subtitle: "Quiet type, generous space",
  },
  cinematic: {
    title: "Cinematic",
    subtitle: "Dramatic light, editorial type",
  },
};
