import { createServerFn } from "@tanstack/react-start";
import type { VisionLayout } from "@/lib/auto-design";

interface AnalyzeInput {
  imageDataUrl: string;
  verse: string;
  canvasLabel: string;
}

export const analyzeLayout = createServerFn({ method: "POST" })
  .validator((input: AnalyzeInput) => input)
  .handler(async ({ data }): Promise<{ ok: true; layout: VisionLayout } | { ok: false; error: string }> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false, error: "AI is not available" };
    }

    const prompt = `You are an art director for premium Christian wall canvases sold as home decor.
Analyze the uploaded image and the Bible verse. Return ONLY JSON with this shape:
{
  "subjectX": number 0-1,
  "subjectY": number 0-1,
  "textAnchor": "top" | "bottom" | "left" | "right",
  "textColor": "#f4efe6" or "#1c1812",
  "overlayColor": "#120e0a" or "#f4efe6",
  "needsOverlay": boolean,
  "overlayOpacity": number 0-1,
  "faceRegion": { "x": 0-1, "y": 0-1, "w": 0-1, "h": 0-1 } or null,
  "enhancement": {
    "brightness": number -0.18 to 0.18,
    "contrast": number -0.08 to 0.28,
    "saturation": number -0.12 to 0.16,
    "temperature": number -0.2 to 0.22,
    "vignette": number 0 to 0.42
  }
}
Rules:
- Keep faces, figures of Jesus, and important bodies fully inside the inner 84% safe print area.
- Place the verse in calm negative space. Never cover a face unless there is no other option.
- If the text region is busy or high-contrast, needsOverlay must be true.
- If the region behind text is bright, use dark text (#1c1812). If dark, use cream text (#f4efe6).
- Keep the photo realistic and respectful. Do not suggest extreme color grading.
- Canvas size: ${data.canvasLabel}
- Verse: ${data.verse.slice(0, 500)}`;

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.2,
          max_tokens: 700,
          response_format: { type: "json_object" },
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: prompt },
                {
                  type: "image_url",
                  image_url: { url: data.imageDataUrl, detail: "low" },
                },
              ],
            },
          ],
        }),
      });

      if (!res.ok) {
        return { ok: false, error: `xAI API error ${res.status}` };
      }

      const body = (await res.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      const content = body.choices?.[0]?.message?.content ?? "";
      const layout = parseLayout(content);
      if (!layout) return { ok: false, error: "Could not parse layout" };
      return { ok: true, layout };
    } catch {
      return { ok: false, error: "Layout analysis failed" };
    }
  });

function parseLayout(content: string): VisionLayout | null {
  const trimmed = content.trim();
  const block = trimmed.startsWith("{")
    ? trimmed
    : (trimmed.match(/\{[\s\S]*\}/)?.[0] ?? "");
  if (!block) return null;
  try {
    return JSON.parse(block) as VisionLayout;
  } catch {
    return null;
  }
}
