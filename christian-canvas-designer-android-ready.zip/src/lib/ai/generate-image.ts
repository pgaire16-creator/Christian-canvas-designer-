import { createServerFn } from "@tanstack/react-start";

interface GenerateInput {
  prompt: string;
}

const STYLE =
  "Photorealistic original Christian fine-art background for a premium wall canvas. Cinematic natural lighting, realistic color, respectful sacred atmosphere, no people crowded in the foreground unless asked, no text, no watermark, no logos, no brand marks. Do not copy or imitate a famous painting, photographer, church, or commercial canvas design. Original composition only.";

export const generateOriginalImage = createServerFn({ method: "POST" })
  .validator((input: GenerateInput) => input)
  .handler(async ({ data }): Promise<{ ok: true; dataUrl: string } | { ok: false; error: string }> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return {
        ok: false,
        error: "Original image generation is not available right now.",
      };
    }

    const userPrompt = data.prompt.trim().slice(0, 400);
    if (userPrompt.length < 8) {
      return { ok: false, error: "Please describe the scene in a little more detail." };
    }

    try {
      const res = await fetch("https://api.x.ai/v1/images/generations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-imagine-image",
          prompt: `${userPrompt}. ${STYLE}`,
          n: 1,
          resolution: "1k",
          aspect_ratio: "3:4",
          response_format: "b64_json",
        }),
      });

      if (!res.ok) {
        return { ok: false, error: `Could not generate an image (${res.status}).` };
      }

      const body = (await res.json()) as {
        data?: { b64_json?: string; url?: string }[];
      };
      const first = body.data?.[0];
      if (first?.b64_json) {
        return { ok: true, dataUrl: `data:image/png;base64,${first.b64_json}` };
      }
      if (first?.url) {
        const imgRes = await fetch(first.url);
        if (!imgRes.ok) {
          return { ok: false, error: "Could not download the generated image." };
        }
        const buf = Buffer.from(await imgRes.arrayBuffer());
        const mime = imgRes.headers.get("content-type") || "image/png";
        return { ok: true, dataUrl: `data:${mime};base64,${buf.toString("base64")}` };
      }
      return { ok: false, error: "The generator returned an empty image." };
    } catch {
      return { ok: false, error: "Image generation failed. Please try again." };
    }
  });
