import type { OverlayKind, DesignState, ImageAnalysis, VariationKind } from "@/lib/types";
import { uid, clamp } from "@/lib/utils";
import { parseVerse } from "@/lib/verses";

export interface VisionLayout {
  subjectX?: number;
  subjectY?: number;
  textAnchor?: ImageAnalysis["textAnchor"];
  textColor?: string;
  overlayColor?: string;
  needsOverlay?: boolean;
  overlayOpacity?: number;
  faceRegion?: { x: number; y: number; w: number; h: number } | null;
  enhancement?: Partial<ImageAnalysis["enhancement"]>;
  notes?: string;
}

export function mergeVision(
  base: ImageAnalysis,
  vision: VisionLayout | null,
): ImageAnalysis {
  if (!vision) return base;
  const next: ImageAnalysis = { ...base, enhancement: { ...base.enhancement } };

  if (typeof vision.subjectX === "number") {
    next.subject = {
      ...next.subject,
      x: clamp(vision.subjectX, 0.15, 0.85),
    };
  }
  if (typeof vision.subjectY === "number") {
    next.subject = {
      ...next.subject,
      y: clamp(vision.subjectY, 0.12, 0.8),
    };
  }
  if (vision.textAnchor) next.textAnchor = vision.textAnchor;
  if (vision.textColor) next.textColor = vision.textColor;
  if (vision.overlayColor) next.overlayColor = vision.overlayColor;
  if (typeof vision.needsOverlay === "boolean") next.needsOverlay = vision.needsOverlay;
  if (typeof vision.overlayOpacity === "number") {
    next.overlayOpacity = clamp(vision.overlayOpacity, 0.12, 0.62);
  }
  if (vision.faceRegion) {
    next.faceRegion = {
      x: clamp(vision.faceRegion.x, 0, 0.8),
      y: clamp(vision.faceRegion.y, 0, 0.8),
      w: clamp(vision.faceRegion.w, 0.12, 0.9),
      h: clamp(vision.faceRegion.h, 0.12, 0.9),
    };
  }
  if (vision.enhancement) {
    const e = vision.enhancement;
    if (typeof e.brightness === "number") {
      next.enhancement.brightness = clamp(e.brightness, -0.18, 0.18);
    }
    if (typeof e.contrast === "number") {
      next.enhancement.contrast = clamp(e.contrast, -0.08, 0.28);
    }
    if (typeof e.saturation === "number") {
      next.enhancement.saturation = clamp(e.saturation, -0.12, 0.16);
    }
    if (typeof e.temperature === "number") {
      next.enhancement.temperature = clamp(e.temperature, -0.2, 0.22);
    }
    if (typeof e.vignette === "number") {
      next.enhancement.vignette = clamp(e.vignette, 0, 0.42);
    }
  }
  return next;
}

export function buildVariations(input: {
  analysis: ImageAnalysis;
  verse: string;
  canvasSizeId: string;
  customWidthIn: number;
  customHeightIn: number;
}): DesignState[] {
  const parsed = parseVerse(input.verse);
  let verseText = parsed.text || input.verse.trim();
  const reference = parsed.reference;
  if (reference) {
    const lowerRef = reference.toLowerCase();
    if (verseText.toLowerCase().endsWith(lowerRef)) {
      verseText = verseText.slice(0, -reference.length).replace(/[-–—\s]+$/, "").trim();
    }
  }
  const kinds: VariationKind[] = ["classic", "modern", "cinematic"];
  return kinds.map((kind) =>
    buildVariation({
      kind,
      analysis: input.analysis,
      verseText,
      reference,
      canvasSizeId: input.canvasSizeId,
      customWidthIn: input.customWidthIn,
      customHeightIn: input.customHeightIn,
    }),
  );
}

function buildVariation(input: {
  kind: VariationKind;
  analysis: ImageAnalysis;
  verseText: string;
  reference: string;
  canvasSizeId: string;
  customWidthIn: number;
  customHeightIn: number;
}): DesignState {
  const { kind, analysis } = input;
  const len = input.verseText.length;
  const lengthScale =
    len < 36 ? 1.32 : len < 80 ? 1.12 : len < 140 ? 1 : len < 220 ? 0.84 : 0.7;

  const titles = {
    classic: "Classic Christian",
    modern: "Modern Premium",
    cinematic: "Cinematic",
  } as const;

  const crop = subjectSafeCrop(analysis, kind);
  const placement = placeText(analysis, kind);
  const overlay = overlayFor(analysis, kind, placement.anchor);

  const baseEnhance = analysis.enhancement;
  const enhance =
    kind === "cinematic"
      ? {
          brightness: baseEnhance.brightness - 0.03,
          contrast: clamp(baseEnhance.contrast + 0.1, -0.08, 0.3),
          saturation: baseEnhance.saturation + 0.02,
          temperature: baseEnhance.temperature + 0.03,
          vignette: clamp(baseEnhance.vignette + 0.14, 0, 0.42),
        }
      : kind === "modern"
        ? {
            brightness: baseEnhance.brightness + 0.02,
            contrast: baseEnhance.contrast * 0.7,
            saturation: baseEnhance.saturation * 0.7,
            temperature: baseEnhance.temperature * 0.6,
            vignette: clamp(baseEnhance.vignette * 0.45, 0, 0.18),
          }
        : {
            brightness: baseEnhance.brightness,
            contrast: baseEnhance.contrast + 0.03,
            saturation: baseEnhance.saturation,
            temperature: baseEnhance.temperature + 0.02,
            vignette: baseEnhance.vignette,
          };

  const lightText = isLightColor(analysis.textColor);
  const textColor =
    kind === "modern" && lightText ? "#f7f3ea" : analysis.textColor;

  const classicSize = 0.052 * lengthScale;
  const modernSize = 0.036 * lengthScale;
  const cinematicSize = 0.058 * lengthScale;

  return {
    id: uid(),
    variation: kind,
    title: titles[kind],
    verseText: input.verseText,
    reference: input.reference,
    fontId:
      kind === "classic" ? "cormorant" : kind === "modern" ? "outfit" : "playfair",
    fontWeight: kind === "modern" ? 400 : 500,
    italic: kind === "classic",
    fontSize:
      kind === "classic"
        ? classicSize
        : kind === "modern"
          ? modernSize
          : cinematicSize,
    letterSpacing: kind === "modern" ? 0.04 : kind === "classic" ? 0.02 : 0.012,
    lineHeight: kind === "modern" ? 1.42 : 1.32,
    textAlign: placement.align,
    textColor,
    textOpacity: 0.96,
    textX: placement.x,
    textY: placement.y,
    textWidth: placement.width,
    textShadow: lightText
      ? { blur: kind === "cinematic" ? 18 : 12, opacity: 0.45, y: 2 }
      : { blur: 0, opacity: 0, y: 0 },
    textOutline:
      analysis.needsOverlay && !lightText
        ? { width: 0.8, color: "rgba(255,255,255,0.28)" }
        : lightText && kind === "cinematic"
          ? { width: 0.6, color: "rgba(18,14,10,0.35)" }
          : null,
    overlay,
    image: {
      cropX: crop.x,
      cropY: crop.y,
      zoom: crop.zoom,
      brightness: enhance.brightness,
      contrast: enhance.contrast,
      saturation: enhance.saturation,
      temperature: enhance.temperature,
      vignette: enhance.vignette,
    },
    canvasSizeId: input.canvasSizeId,
    customWidthIn: input.customWidthIn,
    customHeightIn: input.customHeightIn,
  };
}

function subjectSafeCrop(analysis: ImageAnalysis, kind: VariationKind) {
  let x = analysis.subject.x;
  let y = analysis.subject.y;
  if (analysis.faceRegion) {
    x = analysis.faceRegion.x + analysis.faceRegion.w / 2;
    y = analysis.faceRegion.y + analysis.faceRegion.h / 2;
  }
  if (analysis.textAnchor === "bottom") y = clamp(y - 0.04, 0.28, 0.55);
  if (analysis.textAnchor === "top") y = clamp(y + 0.04, 0.4, 0.7);
  if (analysis.textAnchor === "left") x = clamp(x + 0.06, 0.4, 0.7);
  if (analysis.textAnchor === "right") x = clamp(x - 0.06, 0.3, 0.6);

  const zoom =
    kind === "cinematic" ? 1.12 : kind === "modern" ? 1.02 : 1.06;

  return { x: clamp(x, 0.28, 0.72), y: clamp(y, 0.28, 0.68), zoom };
}

function placeText(
  analysis: ImageAnalysis,
  kind: VariationKind,
): { x: number; y: number; width: number; align: CanvasTextAlign; anchor: ImageAnalysis["textAnchor"] } {
  const anchor = analysis.textAnchor;

  if (kind === "modern") {
    if (anchor === "left") {
      return { x: 0.28, y: 0.62, width: 0.5, align: "left", anchor };
    }
    if (anchor === "right") {
      return { x: 0.72, y: 0.62, width: 0.5, align: "right", anchor };
    }
    if (anchor === "top") {
      return { x: 0.5, y: 0.18, width: 0.72, align: "left", anchor };
    }
    return { x: 0.5, y: 0.84, width: 0.78, align: "left", anchor };
  }

  if (kind === "cinematic") {
    if (anchor === "top") {
      return { x: 0.5, y: 0.2, width: 0.8, align: "center", anchor };
    }
    return { x: 0.5, y: 0.82, width: 0.82, align: "center", anchor: "bottom" };
  }

  if (anchor === "top") {
    return { x: 0.5, y: 0.2, width: 0.76, align: "center", anchor };
  }
  if (anchor === "left") {
    return { x: 0.3, y: 0.78, width: 0.52, align: "left", anchor };
  }
  if (anchor === "right") {
    return { x: 0.7, y: 0.78, width: 0.52, align: "right", anchor };
  }
  return { x: 0.5, y: 0.82, width: 0.78, align: "center", anchor };
}

function overlayFor(
  analysis: ImageAnalysis,
  kind: VariationKind,
  anchor: ImageAnalysis["textAnchor"],
): DesignState["overlay"] {
  const color = analysis.overlayColor;
  if (kind === "modern" && !analysis.needsOverlay) {
    return { kind: "none", color, opacity: 0 };
  }

  let overlayKind: OverlayKind = "bottom-gradient";
  if (anchor === "top") overlayKind = "top-gradient";
  else if (anchor === "left") overlayKind = "left-gradient";
  else if (anchor === "right") overlayKind = "right-gradient";
  else overlayKind = "bottom-gradient";

  if (kind === "modern" && analysis.needsOverlay) {
    return {
      kind: "soft-panel",
      color,
      opacity: clamp(analysis.overlayOpacity * 0.7, 0.16, 0.4),
    };
  }

  const boost = kind === "cinematic" ? 1.15 : 1;
  const force =
    kind === "cinematic" || analysis.needsOverlay || analysis.meanLuma > 0.55;
  if (!force && kind === "classic") {
    return {
      kind: overlayKind,
      color,
      opacity: 0.22,
    };
  }

  return {
    kind: overlayKind,
    color,
    opacity: clamp(analysis.overlayOpacity * boost, 0.2, 0.58),
  };
}

function isLightColor(hex: string) {
  const n = hex.replace("#", "");
  if (n.length < 6) return true;
  const r = parseInt(n.slice(0, 2), 16);
  const g = parseInt(n.slice(2, 4), 16);
  const b = parseInt(n.slice(4, 6), 16);
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 > 0.6;
}

export function cloneDesign(design: DesignState): DesignState {
  return {
    ...design,
    textShadow: { ...design.textShadow },
    textOutline: design.textOutline ? { ...design.textOutline } : null,
    overlay: { ...design.overlay },
    image: { ...design.image },
  };
}
