import { getCanvasSize } from "@/lib/canvas-sizes";
import { ensureCanvasFonts, fontById } from "@/lib/fonts";
import type { DesignState } from "@/lib/types";
import { clamp } from "@/lib/utils";

const imageCache = new Map<string, HTMLImageElement>();

export function loadImage(src: string): Promise<HTMLImageElement> {
  const cached = imageCache.get(src);
  if (cached && cached.complete && cached.naturalWidth > 0) {
    return Promise.resolve(cached);
  }
  return new Promise((resolve, reject) => {
    const img = new Image();
    if (!src.startsWith("blob:") && !src.startsWith("data:")) {
      img.crossOrigin = "anonymous";
    }
    img.onload = () => {
      imageCache.set(src, img);
      resolve(img);
    };
    img.onerror = () => reject(new Error("Could not load the image."));
    img.src = src;
  });
}

export function getPrintPixels(
  design: DesignState,
  dpi: number,
): { width: number; height: number } {
  const size = getCanvasSize(
    design.canvasSizeId,
    design.customWidthIn,
    design.customHeightIn,
  );
  return {
    width: Math.round(size.widthIn * dpi),
    height: Math.round(size.heightIn * dpi),
  };
}

export async function renderDesign(
  canvas: HTMLCanvasElement,
  design: DesignState,
  imageSrc: string,
  options: { guides?: boolean } = {},
): Promise<void> {
  await ensureCanvasFonts();
  const img = await loadImage(imageSrc);
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  paintDesign(ctx, canvas.width, canvas.height, design, img, options.guides);
}

export function paintDesign(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  design: DesignState,
  img: HTMLImageElement,
  guides = false,
): void {
  ctx.save();
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#120e0a";
  ctx.fillRect(0, 0, width, height);

  drawPhoto(ctx, width, height, design, img);
  drawTemperature(ctx, width, height, design.image.temperature);
  drawVignette(ctx, width, height, design.image.vignette);
  drawOverlay(ctx, width, height, design);
  const block = drawVerse(ctx, width, height, design);

  if (guides && block) {
    const margin = 0.08;
    ctx.save();
    ctx.strokeStyle = "rgba(244,239,230,0.28)";
    ctx.setLineDash([Math.max(4, width * 0.008), Math.max(4, width * 0.008)]);
    ctx.lineWidth = Math.max(1, width * 0.0012);
    ctx.strokeRect(
      width * margin,
      height * margin,
      width * (1 - margin * 2),
      height * (1 - margin * 2),
    );
    ctx.restore();
  }

  ctx.restore();
}

function drawPhoto(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  design: DesignState,
  img: HTMLImageElement,
) {
  const { zoom, cropX, cropY, brightness, contrast, saturation } = design.image;
  const scale =
    Math.max(width / img.naturalWidth, height / img.naturalHeight) * zoom;
  const dw = img.naturalWidth * scale;
  const dh = img.naturalHeight * scale;
  let dx = width / 2 - cropX * dw;
  let dy = height / 2 - cropY * dh;
  dx = Math.min(0, Math.max(width - dw, dx));
  dy = Math.min(0, Math.max(height - dh, dy));

  const b = 1 + brightness;
  const c = 1 + contrast;
  const s = 1 + saturation;
  ctx.filter = `brightness(${b}) contrast(${c}) saturate(${s})`;
  ctx.drawImage(img, dx, dy, dw, dh);
  ctx.filter = "none";
}

function drawTemperature(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  temperature: number,
) {
  if (Math.abs(temperature) < 0.01) return;
  ctx.save();
  ctx.globalCompositeOperation = "soft-light";
  ctx.globalAlpha = Math.min(0.5, Math.abs(temperature) * 0.9);
  ctx.fillStyle = temperature > 0 ? "#e8a15a" : "#6a8ec8";
  ctx.fillRect(0, 0, width, height);
  ctx.restore();
}

function drawVignette(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  amount: number,
) {
  if (amount <= 0.01) return;
  const g = ctx.createRadialGradient(
    width * 0.5,
    height * 0.42,
    Math.min(width, height) * 0.18,
    width * 0.5,
    height * 0.5,
    Math.max(width, height) * 0.72,
  );
  g.addColorStop(0, "rgba(8,6,4,0)");
  g.addColorStop(1, `rgba(8,6,4,${clamp(amount, 0, 0.7)})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, width, height);
}

function drawOverlay(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  design: DesignState,
) {
  const { kind, color, opacity } = design.overlay;
  if (kind === "none" || opacity <= 0.01) return;
  ctx.save();
  ctx.globalAlpha = opacity;

  if (kind === "soft-panel") {
    const padX = width * design.textWidth * 0.08;
    const boxW = width * design.textWidth + padX * 2;
    const boxX =
      design.textAlign === "left"
        ? width * design.textX - padX
        : design.textAlign === "right"
          ? width * design.textX - boxW + padX
          : width * design.textX - boxW / 2;
    const boxH = height * 0.28;
    const boxY = height * design.textY - boxH * 0.55;
    roundRect(ctx, boxX, boxY, boxW, boxH, Math.min(width, height) * 0.02);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.restore();
    return;
  }

  let gradient: CanvasGradient;
  if (kind === "top-gradient") {
    gradient = ctx.createLinearGradient(0, 0, 0, height * 0.55);
    gradient.addColorStop(0, color);
    gradient.addColorStop(1, hexAlpha(color, 0));
  } else if (kind === "left-gradient") {
    gradient = ctx.createLinearGradient(0, 0, width * 0.62, 0);
    gradient.addColorStop(0, color);
    gradient.addColorStop(1, hexAlpha(color, 0));
  } else if (kind === "right-gradient") {
    gradient = ctx.createLinearGradient(width, 0, width * 0.38, 0);
    gradient.addColorStop(0, color);
    gradient.addColorStop(1, hexAlpha(color, 0));
  } else {
    gradient = ctx.createLinearGradient(0, height * 0.42, 0, height);
    gradient.addColorStop(0, hexAlpha(color, 0));
    gradient.addColorStop(1, color);
  }
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);
  ctx.restore();
}

function drawVerse(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  design: DesignState,
) {
  const text = design.verseText.trim();
  if (!text && !design.reference.trim()) return null;

  const unit = Math.min(width, height);
  const font = fontById(design.fontId);
  const fontSize = Math.max(10, design.fontSize * unit);
  const maxWidth = width * design.textWidth;
  const italic = design.italic ? "italic " : "";
  ctx.font = `${italic}${design.fontWeight} ${fontSize}px "${font.family}", serif`;
  ctx.textAlign = design.textAlign;
  ctx.textBaseline = "top";
  setLetterSpacing(ctx, `${design.letterSpacing * fontSize}px`);

  const lines = wrapText(ctx, text, maxWidth);
  if (design.reference.trim()) {
    const ref = design.reference.trim().toLowerCase();
    const last = (lines[lines.length - 1] ?? "").trim().toLowerCase();
    if (last === ref) lines.pop();
  }
  const lineHeight = fontSize * design.lineHeight;
  const citation = design.reference.trim();
  const citeSize = Math.max(10, fontSize * 0.38);
  const citeGap = fontSize * 0.55;
  const ruleH = fontSize * 0.08;
  const blockH =
    lines.length * lineHeight +
    (citation ? citeGap + ruleH + citeSize * 1.2 : 0);

  const originX = width * design.textX;
  let top = height * design.textY - blockH / 2;
  const margin = height * 0.08;
  top = clamp(top, margin, height - margin - blockH);

  ctx.save();
  ctx.globalAlpha = design.textOpacity;
  if (design.textShadow.opacity > 0) {
    ctx.shadowColor = `rgba(8,6,4,${design.textShadow.opacity})`;
    ctx.shadowBlur = design.textShadow.blur * (unit / 900);
    ctx.shadowOffsetY = design.textShadow.y * (unit / 900);
  }

  ctx.fillStyle = design.textColor;
  if (design.textOutline) {
    ctx.strokeStyle = design.textOutline.color;
    ctx.lineWidth = design.textOutline.width * (unit / 700);
    ctx.lineJoin = "round";
  }

  for (let i = 0; i < lines.length; i++) {
    const y = top + i * lineHeight;
    const line = lines[i]!;
    if (design.textOutline) ctx.strokeText(line, originX, y);
    ctx.fillText(line, originX, y);
  }

  if (citation) {
    const citeY = top + lines.length * lineHeight + citeGap;
    const ruleW = Math.min(maxWidth * 0.18, unit * 0.12);
    const ruleX =
      design.textAlign === "left"
        ? originX
        : design.textAlign === "right"
          ? originX - ruleW
          : originX - ruleW / 2;
    ctx.shadowBlur = 0;
    ctx.globalAlpha = design.textOpacity * 0.8;
    ctx.fillRect(ruleX, citeY - ruleH, ruleW, Math.max(1, unit * 0.0014));

    ctx.font = `500 ${citeSize}px "Cinzel", "Outfit", sans-serif`;
    setLetterSpacing(ctx, `${citeSize * 0.22}px`);
    ctx.fillStyle = design.textColor;
    ctx.fillText(citation.toUpperCase(), originX, citeY + ruleH * 2);
  }

  ctx.restore();
  setLetterSpacing(ctx, "0px");

  return { top, height: blockH, width: maxWidth };
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
): string[] {
  if (!text) return [];
  const paragraphs = text.split(/\n+/);
  const lines: string[] = [];
  for (const para of paragraphs) {
    const words = para.trim().split(/\s+/).filter(Boolean);
    let current = "";
    for (const word of words) {
      const next = current ? `${current} ${word}` : word;
      if (ctx.measureText(next).width > maxWidth && current) {
        lines.push(current);
        current = word;
      } else {
        current = next;
      }
    }
    if (current) lines.push(current);
  }
  return lines.length ? lines : [text];
}

function setLetterSpacing(ctx: CanvasRenderingContext2D, value: string) {
  const writable = ctx as CanvasRenderingContext2D & { letterSpacing?: string };
  if (typeof writable.letterSpacing === "string" || "letterSpacing" in ctx) {
    writable.letterSpacing = value;
  }
}

function hexAlpha(hex: string, a: number) {
  const n = hex.replace("#", "");
  if (n.length < 6) return `rgba(18,14,10,${a})`;
  const r = parseInt(n.slice(0, 2), 16);
  const g = parseInt(n.slice(2, 4), 16);
  const b = parseInt(n.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}
