export interface SampleVerse {
  id: string;
  reference: string;
  text: string;
}

export const SAMPLE_VERSES: SampleVerse[] = [
  {
    id: "john-3-16",
    reference: "John 3:16",
    text: "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life.",
  },
  {
    id: "psalm-23",
    reference: "Psalm 23:1",
    text: "The Lord is my shepherd; I shall not want.",
  },
  {
    id: "phil-4-13",
    reference: "Philippians 4:13",
    text: "I can do all things through Christ who strengthens me.",
  },
  {
    id: "isaiah-41-10",
    reference: "Isaiah 41:10",
    text: "Fear not, for I am with you; be not dismayed, for I am your God. I will strengthen you, I will help you, I will uphold you with my righteous right hand.",
  },
  {
    id: "jer-29-11",
    reference: "Jeremiah 29:11",
    text: "For I know the plans I have for you, declares the Lord, plans for welfare and not for evil, to give you a future and a hope.",
  },
  {
    id: "prov-3-5",
    reference: "Proverbs 3:5-6",
    text: "Trust in the Lord with all your heart, and do not lean on your own understanding. In all your ways acknowledge him, and he will make straight your paths.",
  },
  {
    id: "rom-8-28",
    reference: "Romans 8:28",
    text: "And we know that for those who love God all things work together for good, for those who are called according to his purpose.",
  },
  {
    id: "john-14-6",
    reference: "John 14:6",
    text: "Jesus said to him, “I am the way, and the truth, and the life. No one comes to the Father except through me.”",
  },
];

const REF_LINE =
  /^(?:[-–—]\s*)?((?:(?:[1-3]|I{1,3})\s*)?[A-Za-z][A-Za-z.'’]+(?:\s+[A-Za-z][A-Za-z.'’]+){0,3})\s+(\d{1,3}\s*:\s*\d{1,3}(?:\s*[-–—]\s*\d{1,3})?)\s*$/;

const REF_TAIL =
  /(?:[-–—]\s*)?((?:(?:[1-3]|I{1,3})\s*)?[A-Za-z][A-Za-z.'’]+(?:\s+[A-Za-z][A-Za-z.'’]+){0,3})\s+(\d{1,3}\s*:\s*\d{1,3}(?:\s*[-–—]\s*\d{1,3})?)\s*$/;

export function parseVerse(raw: string): { text: string; reference: string } {
  const trimmed = raw.trim();
  if (!trimmed) return { text: "", reference: "" };

  const lines = trimmed.split(/\n+/);
  const last = (lines[lines.length - 1] ?? "").trim();
  if (lines.length > 1 && last.length < 48) {
    const lineMatch = last.match(REF_LINE);
    if (lineMatch) {
      return {
        text: lines.slice(0, -1).join("\n").trim(),
        reference: normalizeRef(lineMatch[1]!, lineMatch[2]!),
      };
    }
  }

  const tail = trimmed.match(REF_TAIL);
  if (tail && tail.index !== undefined && tail.index > 12) {
    return {
      text: trimmed.slice(0, tail.index).replace(/[-–—\s]+$/, "").trim(),
      reference: normalizeRef(tail[1]!, tail[2]!),
    };
  }

  return { text: trimmed, reference: "" };
}

export function formatVerseInput(text: string, reference: string) {
  const body = text.trim();
  const ref = reference.trim();
  if (!ref) return body;
  if (!body) return ref;
  return `${body}\n${ref}`;
}

function normalizeRef(book: string, verse: string) {
  const cleanBook = book.replace(/\s+/g, " ").trim();
  const cleanVerse = verse.replace(/\s+/g, "");
  return `${cleanBook} ${cleanVerse}`;
}
