import { analyzeLayout } from "@/lib/ai/analyze";
import { buildVariations, mergeVision, type VisionLayout } from "@/lib/auto-design";
import { getCanvasSize } from "@/lib/canvas-sizes";
import { loadImage } from "@/lib/canvas-render";
import { analyzeImage, downsampleToJpeg } from "@/lib/image-analysis";
import { useStudio } from "@/lib/store";
import { sleep } from "@/lib/utils";

const STATUS = [
  "Reading light and composition",
  "Protecting the subject",
  "Choosing type and placement",
  "Balancing contrast",
  "Setting print-safe margins",
  "Composing three variations",
];

export async function runAutoDesign(): Promise<void> {
  const studio = useStudio.getState();
  const { imageSrc, verse, canvasSizeId, customWidthIn, customHeightIn } = studio;
  if (!imageSrc || !verse.trim()) return;

  studio.setDesigning(STATUS[0]!);
  const started = Date.now();
  let tick = 0;
  const timer = window.setInterval(() => {
    tick += 1;
    useStudio.setState({ designStatus: STATUS[tick % STATUS.length]! });
  }, 700);

  try {
    const img = await loadImage(imageSrc);
    const local = analyzeImage(img, canvasSizeId);
    const sizeId = local.recommendedSizeId;
    const size = getCanvasSize(sizeId, customWidthIn, customHeightIn);

    let vision: VisionLayout | null = null;
    try {
      const small = downsampleToJpeg(img, 480, 0.7);
      if (small) {
        const result = await Promise.race([
          analyzeLayout({
            data: {
              imageDataUrl: small,
              verse: verse.trim(),
              canvasLabel: size.label,
            },
          }),
          sleep(10_000).then(() => null),
        ]);
        if (result && result.ok) vision = result.layout;
      }
    } catch {
      vision = null;
    }

    const analysis = mergeVision(local, vision);
    const variations = buildVariations({
      analysis,
      verse,
      canvasSizeId: sizeId,
      customWidthIn,
      customHeightIn,
    });

    const elapsed = Date.now() - started;
    if (elapsed < 2400) await sleep(2400 - elapsed);

    window.clearInterval(timer);
    useStudio.getState().finishDesign({
      analysis,
      variations,
      canvasSizeId: sizeId,
    });
  } catch (error) {
    window.clearInterval(timer);
    throw error;
  }
}
