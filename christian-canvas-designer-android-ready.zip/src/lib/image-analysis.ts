import { pickAutoSize } from "@/lib/canvas-sizes";
import type { GridCell, ImageAnalysis, TextAnchor } from "@/lib/types";
import { clamp } from "@/lib/utils";

const GRID = 3;
const SAMPLE = 96;

function luma(r: number, g: number, b: number) {
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
}

function sat(r: number, g: number, b: number) {
  const max = Math.max(r, g, b) / 255;
  const min = Math.min(r, g, b) / 255;
  const l = (max + min) / 2;
  if (max === min) return 0;
  const d = max - min;
  return l > 0.5 ? d / (2 - max - min) : d / (max + min);
}

export function analyzeImage(
  img: HTMLImageElement,
  preferredSizeId: string,
): ImageAnalysis {
  const canvas = document.createElement("canvas");
  canvas.width = SAMPLE;
  canvas.height = SAMPLE;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) {
    return fallbackAnalysis(img, preferredSizeId);
  }

  ctx.drawImage(img, 0, 0, SAMPLE, SAMPLE);
  const { data } = ctx.getImageData(0, 0, SAMPLE, SAMPLE);

  const cellW = SAMPLE / GRID;
  const cells: GridCell[] = Array.from({ length: GRID * GRID }, () => ({
    luma: 0,
    variance: 0,
    edge: 0,
    sat: 0,
  }));
  const cellLumas: number[][] = Array.from({ length: GRID * GRID }, () => []);

  let lumaSum = 0;
  let satSum = 0;
  const lumas: number[] = [];

  for (let y = 0; y < SAMPLE; y++) {
    for (let x = 0; x < SAMPLE; x++) {
      const i = (y * SAMPLE + x) * 4;
      const r = data[i] ?? 0;
      const g = data[i + 1] ?? 0;
      const b = data[i + 2] ?? 0;
      const Y = luma(r, g, b);
      const S = sat(r, g, b);
      lumaSum += Y;
      satSum += S;
      lumas.push(Y);

      const col = Math.min(GRID - 1, Math.floor(x / cellW));
      const row = Math.min(GRID - 1, Math.floor(y / cellW));
      const idx = row * GRID + col;
      const cell = cells[idx]!;
      cell.luma += Y;
      cell.sat += S;
      cellLumas[idx]!.push(Y);

      if (x < SAMPLE - 1 && y < SAMPLE - 1) {
        const iRight = (y * SAMPLE + (x + 1)) * 4;
        const iDown = ((y + 1) * SAMPLE + x) * 4;
        const yr = luma(data[iRight] ?? 0, data[iRight + 1] ?? 0, data[iRight + 2] ?? 0);
        const yd = luma(data[iDown] ?? 0, data[iDown + 1] ?? 0, data[iDown + 2] ?? 0);
        cell.edge += Math.abs(Y - yr) + Math.abs(Y - yd);
      }
    }
  }

  const n = SAMPLE * SAMPLE;
  const meanLuma = lumaSum / n;
  const meanSat = satSum / n;
  let varSum = 0;
  for (const Y of lumas) varSum += (Y - meanLuma) ** 2;
  const contrast = Math.sqrt(varSum / n);

  for (let i = 0; i < cells.length; i++) {
    const samples = cellLumas[i]!;
    const cell = cells[i]!;
    const count = samples.length || 1;
    cell.luma /= count;
    cell.sat /= count;
    const m = cell.luma;
    let v = 0;
    for (const Y of samples) v += (Y - m) ** 2;
    cell.variance = v / count;
    cell.edge /= count;
  }

  let subjectIdx = 0;
  let maxEdge = -1;
  for (let i = 0; i < cells.length; i++) {
    const score = cells[i]!.edge * 1.15 + cells[i]!.variance;
    if (score > maxEdge) {
      maxEdge = score;
      subjectIdx = i;
    }
  }

  const subjectCol = subjectIdx % GRID;
  const subjectRow = Math.floor(subjectIdx / GRID);
  const textAnchor = pickTextAnchor(subjectRow, subjectCol, cells);
  const textCell = cellForAnchor(textAnchor, cells);
  const needsOverlay = textCell.variance > 0.012 || textCell.edge > 0.045;
  const overlayOpacity = clamp(
    0.22 + textCell.variance * 4 + textCell.edge * 2,
    0.18,
    0.55,
  );

  const textOnDark = textCell.luma < 0.52;
  const textColor = textOnDark ? "#f4efe6" : "#1c1812";
  const overlayColor = textOnDark ? "#120e0a" : "#f4efe6";

  const enhancement = {
    brightness: 0,
    contrast: 0,
    saturation: 0,
    temperature: 0,
    vignette: 0.12,
  };

  if (contrast < 0.14) enhancement.contrast += 0.16;
  else if (contrast < 0.18) enhancement.contrast += 0.08;
  else if (contrast > 0.32) enhancement.contrast -= 0.05;

  if (meanLuma > 0.72) enhancement.brightness -= 0.1;
  else if (meanLuma > 0.62) enhancement.brightness -= 0.04;
  else if (meanLuma < 0.26) enhancement.brightness += 0.1;
  else if (meanLuma < 0.34) enhancement.brightness += 0.05;

  if (meanSat < 0.12) enhancement.saturation += 0.08;
  else if (meanSat > 0.48) enhancement.saturation -= 0.06;

  if (meanLuma < 0.42) enhancement.temperature += 0.06;
  enhancement.vignette = clamp(0.1 + (0.22 - contrast), 0.08, 0.28);

  const aspect = img.width / img.height || 0.75;
  const recommended = pickAutoSize(aspect);

  return {
    width: img.width,
    height: img.height,
    aspect,
    meanLuma,
    contrast,
    saturation: meanSat,
    grid: cells,
    subject: {
      col: subjectCol,
      row: subjectRow,
      x: (subjectCol + 0.5) / GRID,
      y: (subjectRow + 0.5) / GRID,
    },
    textAnchor,
    textColor,
    overlayColor,
    needsOverlay,
    overlayOpacity,
    recommendedSizeId: preferredSizeId === "auto" ? recommended.id : preferredSizeId,
    faceRegion: null,
    enhancement,
  };
}

function pickTextAnchor(
  subjectRow: number,
  subjectCol: number,
  cells: GridCell[],
): TextAnchor {
  if (subjectRow <= 1) return "bottom";
  if (subjectRow === 2) return "top";

  const leftBusy =
    (cells[0]!.variance + cells[3]!.variance + cells[6]!.variance) / 3;
  const rightBusy =
    (cells[2]!.variance + cells[5]!.variance + cells[8]!.variance) / 3;

  if (subjectCol === 0 && rightBusy < leftBusy) return "right";
  if (subjectCol === 2 && leftBusy < rightBusy) return "left";
  return "bottom";
}

function cellForAnchor(anchor: TextAnchor, cells: GridCell[]): GridCell {
  if (anchor === "top") {
    return averageCells([cells[0]!, cells[1]!, cells[2]!]);
  }
  if (anchor === "left") {
    return averageCells([cells[0]!, cells[3]!, cells[6]!]);
  }
  if (anchor === "right") {
    return averageCells([cells[2]!, cells[5]!, cells[8]!]);
  }
  return averageCells([cells[6]!, cells[7]!, cells[8]!]);
}

function averageCells(list: GridCell[]): GridCell {
  const n = list.length || 1;
  return {
    luma: list.reduce((s, c) => s + c.luma, 0) / n,
    variance: list.reduce((s, c) => s + c.variance, 0) / n,
    edge: list.reduce((s, c) => s + c.edge, 0) / n,
    sat: list.reduce((s, c) => s + c.sat, 0) / n,
  };
}

function fallbackAnalysis(
  img: HTMLImageElement,
  preferredSizeId: string,
): ImageAnalysis {
  const aspect = img.width / img.height || 0.75;
  return {
    width: img.width,
    height: img.height,
    aspect,
    meanLuma: 0.4,
    contrast: 0.18,
    saturation: 0.22,
    grid: Array.from({ length: 9 }, () => ({
      luma: 0.4,
      variance: 0.02,
      edge: 0.03,
      sat: 0.22,
    })),
    subject: { col: 1, row: 1, x: 0.5, y: 0.42 },
    textAnchor: "bottom",
    textColor: "#f4efe6",
    overlayColor: "#120e0a",
    needsOverlay: true,
    overlayOpacity: 0.36,
    recommendedSizeId:
      preferredSizeId === "auto" ? pickAutoSize(aspect).id : preferredSizeId,
    faceRegion: null,
    enhancement: {
      brightness: 0,
      contrast: 0.08,
      saturation: 0.04,
      temperature: 0.04,
      vignette: 0.16,
    },
  };
}

export function downsampleToJpeg(
  img: HTMLImageElement,
  maxDim = 512,
  quality = 0.72,
): string {
  const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  ctx.drawImage(img, 0, 0, w, h);
  return canvas.toDataURL("image/jpeg", quality);
}
