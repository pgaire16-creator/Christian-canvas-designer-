import { create } from "zustand";
import { cloneDesign } from "@/lib/auto-design";
import type {
  AppStep,
  DesignState,
  ImageOrigin,
  ImageAnalysis,
} from "@/lib/types";

const HISTORY_LIMIT = 40;

interface StudioState {
  step: AppStep;
  imageSrc: string | null;
  imageOrigin: ImageOrigin | null;
  verse: string;
  canvasSizeId: string;
  customWidthIn: number;
  customHeightIn: number;
  analysis: ImageAnalysis | null;
  variations: DesignState[];
  selectedId: string | null;
  history: DesignState[];
  future: DesignState[];
  designBusy: boolean;
  designStatus: string;
  exportBusy: boolean;
  generateOpen: boolean;
  editMode: "text" | "image";
  setStep: (step: AppStep) => void;
  setVerse: (verse: string) => void;
  setCanvasSizeId: (id: string) => void;
  setCustomSize: (widthIn: number, heightIn: number) => void;
  setImage: (src: string, origin: ImageOrigin) => void;
  clearImage: () => void;
  setDesigning: (status: string) => void;
  finishDesign: (input: {
    analysis: ImageAnalysis;
    variations: DesignState[];
    canvasSizeId: string;
  }) => void;
  selectVariation: (id: string) => void;
  selectedDesign: () => DesignState | null;
  patchDesign: (patch: Partial<DesignState>, commit?: boolean) => void;
  patchImage: (patch: Partial<DesignState["image"]>, commit?: boolean) => void;
  commit: () => void;
  undo: () => void;
  redo: () => void;
  setGenerateOpen: (open: boolean) => void;
  setExportBusy: (busy: boolean) => void;
  setEditMode: (mode: "text" | "image") => void;
  resetToCompose: () => void;
}

export const useStudio = create<StudioState>((set, get) => ({
  step: "compose",
  imageSrc: null,
  imageOrigin: null,
  verse: "",
  canvasSizeId: "auto",
  customWidthIn: 16,
  customHeightIn: 20,
  analysis: null,
  variations: [],
  selectedId: null,
  history: [],
  future: [],
  designBusy: false,
  designStatus: "",
  exportBusy: false,
  generateOpen: false,
  editMode: "text",

  setStep: (step) => set({ step }),
  setVerse: (verse) => set({ verse }),
  setCanvasSizeId: (canvasSizeId) => set({ canvasSizeId }),
  setCustomSize: (customWidthIn, customHeightIn) =>
    set({ customWidthIn, customHeightIn }),
  setImage: (imageSrc, imageOrigin) => set({ imageSrc, imageOrigin }),
  clearImage: () => set({ imageSrc: null, imageOrigin: null }),
  setDesigning: (designStatus) =>
    set({ step: "designing", designBusy: true, designStatus }),
  finishDesign: ({ analysis, variations, canvasSizeId }) =>
    set({
      analysis,
      variations,
      canvasSizeId,
      selectedId: variations[0]?.id ?? null,
      step: "gallery",
      designBusy: false,
      designStatus: "",
      history: [],
      future: [],
    }),
  selectVariation: (selectedId) =>
    set({ selectedId, history: [], future: [], step: "editor" }),
  selectedDesign: () => {
    const { variations, selectedId } = get();
    return variations.find((v) => v.id === selectedId) ?? null;
  },
  patchDesign: (patch, commit = true) => {
    const { variations, selectedId, history } = get();
    const current = variations.find((v) => v.id === selectedId);
    if (!current) return;
    const next = { ...cloneDesign(current), ...patch, id: current.id };
    if (patch.image) next.image = { ...current.image, ...patch.image };
    if (patch.overlay) next.overlay = { ...current.overlay, ...patch.overlay };
    if (patch.textShadow) {
      next.textShadow = { ...current.textShadow, ...patch.textShadow };
    }
    set({
      variations: variations.map((v) => (v.id === current.id ? next : v)),
      history: commit
        ? [...history, cloneDesign(current)].slice(-HISTORY_LIMIT)
        : history,
      future: commit ? [] : get().future,
    });
  },
  patchImage: (patch, commit = true) => {
    const current = get().selectedDesign();
    if (!current) return;
    get().patchDesign({ image: { ...current.image, ...patch } }, commit);
  },
  commit: () => {
    const current = get().selectedDesign();
    if (!current) return;
    set({
      history: [...get().history, cloneDesign(current)].slice(-HISTORY_LIMIT),
      future: [],
    });
  },
  undo: () => {
    const { history, variations, selectedId, future } = get();
    const current = variations.find((v) => v.id === selectedId);
    const prev = history[history.length - 1];
    if (!current || !prev) return;
    set({
      history: history.slice(0, -1),
      future: [...future, cloneDesign(current)],
      variations: variations.map((v) =>
        v.id === current.id ? { ...cloneDesign(prev), id: current.id } : v,
      ),
    });
  },
  redo: () => {
    const { future, variations, selectedId, history } = get();
    const current = variations.find((v) => v.id === selectedId);
    const next = future[future.length - 1];
    if (!current || !next) return;
    set({
      future: future.slice(0, -1),
      history: [...history, cloneDesign(current)].slice(-HISTORY_LIMIT),
      variations: variations.map((v) =>
        v.id === current.id ? { ...cloneDesign(next), id: current.id } : v,
      ),
    });
  },
  setGenerateOpen: (generateOpen) => set({ generateOpen }),
  setExportBusy: (exportBusy) => set({ exportBusy }),
  setEditMode: (editMode) => set({ editMode }),
  resetToCompose: () =>
    set({
      step: "compose",
      variations: [],
      selectedId: null,
      history: [],
      future: [],
      analysis: null,
      designBusy: false,
    }),
}));
