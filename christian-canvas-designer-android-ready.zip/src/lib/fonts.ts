export interface CanvasFont {
  id: string;
  family: string;
  label: string;
  category: "elegant-serif" | "modern-serif" | "editorial" | "sans";
  weights: number[];
}

export const CANVAS_FONTS: CanvasFont[] = [
  {
    id: "cormorant",
    family: "Cormorant Garamond",
    label: "Cormorant",
    category: "elegant-serif",
    weights: [400, 500, 600, 700],
  },
  {
    id: "playfair",
    family: "Playfair Display",
    label: "Playfair",
    category: "editorial",
    weights: [400, 500, 600],
  },
  {
    id: "cinzel",
    family: "Cinzel",
    label: "Cinzel",
    category: "modern-serif",
    weights: [400, 500, 600],
  },
  {
    id: "baskerville",
    family: "Libre Baskerville",
    label: "Baskerville",
    category: "elegant-serif",
    weights: [400, 700],
  },
  {
    id: "outfit",
    family: "Outfit",
    label: "Outfit",
    category: "sans",
    weights: [300, 400, 500, 600],
  },
];

export const FONT_LOAD_SPECS = [
  '500 64px "Cormorant Garamond"',
  'italic 500 64px "Cormorant Garamond"',
  '500 64px "Playfair Display"',
  'italic 400 64px "Playfair Display"',
  '500 64px "Cinzel"',
  '400 64px "Libre Baskerville"',
  'italic 400 64px "Libre Baskerville"',
  '400 64px "Outfit"',
  '500 64px "Outfit"',
];

let fontsPromise: Promise<void> | null = null;

export function ensureCanvasFonts(): Promise<void> {
  if (typeof document === "undefined") return Promise.resolve();
  if (!fontsPromise) {
    fontsPromise = (async () => {
      try {
        await document.fonts.ready;
        await Promise.all(
          FONT_LOAD_SPECS.map((spec) => document.fonts.load(spec)),
        );
      } catch {
        /* drawing will fall back to serif/sans */
      }
    })();
  }
  return fontsPromise;
}

export function fontById(id: string): CanvasFont {
  return CANVAS_FONTS.find((f) => f.id === id) ?? CANVAS_FONTS[0]!;
}
